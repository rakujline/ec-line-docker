var require = meteorInstall({"imports":{"vender":{"strut":{"importNew":{"collection.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/vender/strut/importNew/collection.js                                                                     //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  strutNewItems: () => strutNewItems
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Meta;
module.link("../../../shared/meteorMongo/meta", {
  default(v) {
    Meta = v;
  }

}, 2);
const strutNewItems = new Mongo.Collection('strutNewItems', {
  idGeneration: 'MONGO'
});

if (Meteor.isServer) {
  Meteor.publish('strutNewItems', () => strutNewItems.find());
}

Meta.inject(strutNewItems);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"import.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/vender/strut/importNew/import.js                                                                         //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.link("./method");
module.link("./collection");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/vender/strut/importNew/method.js                                                                         //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("../../../data/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let strutNewItems;
module.link("./collection", {
  strutNewItems(v) {
    strutNewItems = v;
  }

}, 2);

if (Meteor.isServer) {
  Meteor.methods({
    /**
     *
     *
     * @param {*} file 取り込むCSVファイルの絶対パス
     */
    'strut.importNew'(file) {
      strutNewItems.remove({});
      Mongo.importCsv(file, strutNewItems.rawCollection());
    }

  });
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"import.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/vender/strut/import.js                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.link("./importNew/import");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"import.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/vender/import.js                                                                                         //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.link("./strut/import");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"shared":{"meteorMongo":{"meta.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/shared/meteorMongo/meta.js                                                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  default: () => Meta
});

class Meta {
  /**
   *
   *
   * @static
   * @param {Mongo.Collection} meteorMongoCollection
   * @returns
   * @memberof Meta
   */
  static inject(meteorMongoCollection) {
    // additional function for collection
    meteorMongoCollection.selectedItems = () => meteorMongoCollection.find({
      'meta.select': true
    }); // methods for each documents


    meteorMongoCollection.helpers({
      toggle() {
        this.select(!this.meta.select);
      },

      select(bool) {
        meteorMongoCollection.update({
          _id: this._id
        }, {
          $set: {
            'meta.select': bool
          }
        });
        this.meta.select = bool;
      },

      isSelected() {
        return this.meta.select;
      }

    }); // security

    meteorMongoCollection.allow({
      update: () => true
    });
  }
  /**
   * @deprecated
   * @param {*} doc
   */


  static update(doc) {
    // ドキュメントデータを検査し、
    // 欠落している場合に metaプロパティ を作成する
    if (typeof doc.meta === 'undefined') {
      doc.meta = {};
    }

    doc.meta.updateTime = Date.now();
  }

  static wrap(doc) {
    return {
      meta: {
        updateTime: Date.now(),
        select: false
      },
      data: doc
    };
  }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"collections":{"config.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/collections/config.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  Config: () => Config
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
const Config = new Mongo.Collection('config', {
  idGeneration: 'MONGO'
});

if (Meteor.isServer) {
  if (!Config.find().count()) {
    Config.insert({});
  }

  Meteor.publish('config', () => Config.find({}, {
    limit: 1
  }));
  Meteor.methods({
    'config.update'(doc) {
      Config.update({}, doc);
    }

  });
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"importIr.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/collections/importIr.js                                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  ImportIrVARIABLES: () => ImportIrVARIABLES
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Meta;
module.link("../shared/meteorMongo/meta", {
  default(v) {
    Meta = v;
  }

}, 2);
const ImportIrVARIABLES = {
  workdir: 'items/importIr',
  ite: [{
    symbol: 'itemRobotItems',
    csvfile: 'ir-item.csv',
    mongocoll: null,
    mongoCollMeteor: null
  }, {
    symbol: 'itemRobotItemOption',
    csvfile: 'ir-itemoption.csv',
    mongocoll: null,
    mongoCollMeteor: null
  }, {
    symbol: 'itemRobotWowma',
    csvfile: 'ir-itemsub_Wowma!.csv',
    mongocoll: null,
    mongoCollMeteor: null
  }, {
    symbol: 'itemRobotYshop',
    csvfile: 'ir-itemsub_Yahoo.csv',
    mongocoll: null,
    mongoCollMeteor: null
  }, {
    symbol: 'itemRobotRakuten',
    csvfile: 'ir-itemsub_楽天.csv',
    mongocoll: null,
    mongoCollMeteor: null
  }, {
    symbol: 'itemRobotSelection',
    csvfile: 'ir-selection.csv',
    mongocoll: null,
    mongoCollMeteor: null
  }, {
    symbol: 'itemRobotSelectionWowma',
    csvfile: 'ir-selectionsub_Wowma!.csv',
    mongocoll: null,
    mongoCollMeteor: null
  }, {
    symbol: 'itemRobotSelectionYshop',
    csvfile: 'ir-selectionsub_Yahoo.csv',
    mongocoll: null,
    mongoCollMeteor: null
  }, {
    symbol: 'itemRobotSelectionRakuten',
    csvfile: 'ir-selectionsub_楽天.csv',
    mongocoll: null,
    mongoCollMeteor: null
  }]
};
ImportIrVARIABLES.ite.forEach(ite => {
  ite.mongoCollMeteor = new Mongo.Collection(ite.symbol, {
    idGeneration: 'MONGO'
  });
  ite.mongocoll = Meteor.isServer ? ite.mongoCollMeteor.rawCollection() : null;
  Meta.inject(ite.mongoCollMeteor);
  ite.mongoCollMeteor.allow({
    insert: () => true,
    remove: () => true
  });

  if (Meteor.isServer) {
    Meteor.publish(ite.symbol, () => ite.mongoCollMeteor.find());
  }
});

if (Meteor.isServer) {
  // Meteor.publish(
  //   'ImportIrItem',
  //   () => ImportIrItem.find(),
  // );
  Meteor.methods({
    /**
     *
     *
     * @param {String} subscribeName
     */
    'itemRobot.removeCollection'(subscribeName) {
      ImportIrVARIABLES.ite.forEach(ite => {
        if (ite.symbol === subscribeName) {
          ite.mongoCollMeteor.remove({});
        }
      });
    }

  });
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/collections/items.js                                                                                     //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  Items: () => Items
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Meta;
module.link("../shared/meteorMongo/meta", {
  default(v) {
    Meta = v;
  }

}, 2);
const Items = new Mongo.Collection('items', {
  idGeneration: 'MONGO'
});

if (Meteor.isServer) {
  Meteor.publish('items', () => Items.find({}));
  Items.allow({
    remove: () => true
  });
  Items.deny({
    insert: () => true,
    update: () => true
  });
  Meteor.methods({
    'items.insert'(doc) {
      Meta.update(doc);
      return Items.insert(doc);
    },

    'items.update'(doc) {
      Meta.update(doc);
      return Items.update(doc._id, doc);
    }

  });
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"request.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/collections/request.js                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  Request: () => Request
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
const Request = new Mongo.Collection('request', {
  idGeneration: 'MONGO'
});

if (Meteor.isServer) {
  Meteor.publish('request', () => Request.find());
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"converter":{"mongoOldNew.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/converter/mongoOldNew.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  MongoOldNew: () => MongoOldNew
});
let MongoClient;
module.link("mongodb", {
  MongoClient(v) {
    MongoClient = v;
  }

}, 0);
let Writable, Transform;
module.link("stream", {
  Writable(v) {
    Writable = v;
  },

  Transform(v) {
    Transform = v;
  }

}, 1);

class MongoOldNew {
  constructor(mongouOld, mongouNew) {
    this.title = 'mongoItems old to new';
    this.mongouOld = mongouOld;
    this.mongouNew = mongouNew;
  }

  getOldDbConnect() {
    return Promise.asyncApply(() => {
      const client = Promise.await(new MongoClient(this.mongouOld, {
        useNewUrlParser: true
      }).connect());
      return client;
    });
  }

  getNewDbConnect() {
    return Promise.asyncApply(() => {
      const client = Promise.await(new MongoClient(this.mongouNew, {
        useNewUrlParser: true
      }).connect());
      return client;
    });
  }

  countImportCandidate() {
    return Promise.asyncApply(() => {
      const promise = new Promise((resolve, reject) => Promise.asyncApply(() => {
        let count = 0;
        const readCandidate = Promise.await(this.readableImportCandidate());
        readCandidate.on('data', () => {
          count += 1;
        }).on('end', () => {
          resolve(count);
        }).on('error', err => {
          reject(err);
        });
        readCandidate.resume();
      }));
      return promise;
    });
  }

  readableImportCandidate() {
    return Promise.asyncApply(() => {
      const mongocOld = Promise.await(this.getOldDbConnect());
      const oldDb = mongocOld.db();
      const mongocNew = Promise.await(this.getNewDbConnect());
      const newDb = mongocNew.db();
      const tfNotExist = new Transform({
        objectMode: true,
        transform: (chunk, enc, cb) => Promise.asyncApply(() => {
          // 転送先のデータベースに同じIDが存在するか確かめる
          let data;

          try {
            data = Promise.await(newDb.collection(this.colNew).findOne(chunk._id, {
              projection: {
                _id: 1
              }
            }));
          } catch (err) {
            cb(err);
          }

          if (!data) {
            // 転送先のデータベースに同じIDが存在しなければストリームに渡す
            cb(null, chunk);
          } else {
            cb();
          }
        }),
        final: cb => Promise.asyncApply(() => {
          // 旧データベースとの接続を閉じる
          Promise.await(mongocOld.close());
          Promise.await(mongocNew.close());
          cb();
        })
      });
      const readable = oldDb.collection(this.colOld).find().project().pipe(tfNotExist);
      return readable;
    });
  }

  migrate(read) {
    return Promise.asyncApply(() => {
      // const revCondition = await super.migrate(condition);
      let revRead = read;

      if (!revRead) {
        revRead = Promise.await(this.readableImportCandidate());
      }

      const tfData = new Transform({
        readableObjectMode: true,
        writableObjectMode: true,
        transform: (chunk, enc, cb) => Promise.asyncApply(() => {
          // データの変換
          const data = this.convert(chunk);
          cb(null, data);
        })
      }); // 移行先 mongodb と接続

      const mongocNew = Promise.await(this.getNewDbConnect());
      const newDb = mongocNew.db();
      const tfWriteMongoNew = new Transform({
        readableObjectMode: true,
        writableObjectMode: true,
        transform: (chunk, enc, cb) => Promise.asyncApply(() => {
          let cmr = null;

          try {
            cmr = Promise.await(newDb.collection(this.colNew).insertOne(chunk));
          } catch (err) {
            cb(err);
          }

          cb(null, cmr);
        }),
        final: cb => Promise.asyncApply(() => {
          // データベースとの接続を閉じる
          Promise.await(mongocNew.close());
          cb();
        })
      });
      let count = 0;
      const write = new Writable({
        objectMode: true,
        write: (chunk, enc, cb) => {
          count += chunk.insertedCount;
          cb();
        }
      });
      return new Promise((resolve, reject) => {
        revRead.pipe(tfData).pipe(tfWriteMongoNew).pipe(write).on('finish', () => {
          resolve(count);
        }).on('error', err => {
          reject(err);
        });
      });
    });
  }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongoOldNewExhib.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/converter/mongoOldNewExhib.js                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  MongoOldNewExhib: () => MongoOldNewExhib
});
let uniqid;
module.link("uniqid", {
  default(v) {
    uniqid = v;
  }

}, 0);
let MongoOldNew;
module.link("./mongoOldNew", {
  MongoOldNew(v) {
    MongoOldNew = v;
  }

}, 1);
let Meta;
module.link("../shared/meteorMongo/meta", {
  default(v) {
    Meta = v;
  }

}, 2);

class MongoOldNewExhib extends MongoOldNew {
  constructor(mongouOld, colOld, mongouNew, colNew) {
    super(mongouOld, mongouNew);
    this.title = 'migration of mongo exhibition data from old to new';
    this.colOld = colOld;
    this.colNew = colNew;

    this.convert = chunk => {
      // ドキュメントの構成
      // 基準となる商品情報
      const base = {
        title: chunk.name,
        item: chunk.product,
        description: chunk.description,
        images: chunk.images,
        delivery: chunk.delivery,
        jan: chunk.jan_code,
        class1Name: chunk.class1_name,
        class1Value: chunk.class1_value,
        class2Name: chunk.class2_name,
        class2Value: chunk.class2_value,
        retailPrice: chunk.retail_price,
        tag: chunk.tag,
        close: chunk.close
      }; // 楽天商品情報

      const rakuten = chunk.mall.rakuten ? {
        itemUrl: chunk.mall.rakuten.itemUrl,
        HChoiceName: chunk.mall.rakuten.HChoiceName,
        VChoiceName: chunk.mall.rakuten.VChoiceName
      } : null; // ヤフーショッピング商品情報

      const yshop = chunk.mall.yshop ? {
        itemCode: chunk.mall.yshop.item_code,
        subCode: chunk.mall.yshop.sub_code
      } : null; // ヤフオク商品情報

      const yauct = chunk.mall.yauct ? {
        uid: uniqid(),
        category: chunk.mall.yauct.category,
        minQuantity: chunk.mall.yauct.minQuantity
      } : null; // sharaku-shop 商品情報

      const sharakuShop = chunk.mall.sharakuShop ? {
        product_id: chunk.mall.sharakuShop.product_id,
        product_class_id: chunk.mall.sharakuShop.product_class_id,
        product_stock_id: chunk.mall.sharakuShop.product_stock_id,
        price: chunk.mall.sharakuShop.price
      } : null; // Wowma 楽天商品情報

      const wowma = chunk.mall.wowma ? {
        HChoiceName: chunk.mall.wowma.HChoiceName,
        VChoiceName: chunk.mall.wowma.VChoiceName,
        itemCode: chunk.mall.wowma.itemCode,
        itemManagementId: chunk.mall.wowma.itemManagementId
      } : null;
      const data = {
        base,
        rakuten,
        yshop,
        yauct,
        sharakuShop,
        wowma
      };
      Object.keys(data).forEach(key => {
        data[key] = Meta.wrap(data[key]);
      }); // const data = {
      //   base: Meta.wrap(base),
      //   rakuten: Meta.wrap(rakuten),
      //   yshop: Meta.wrap(yshop),
      //   yauct: Meta.wrap(yauct),
      //   sharakuShop: Meta.wrap(sharakuShop),
      //   wowma: Meta.wrap(wowma),
      // };

      const doc = Meta.wrap(data);
      doc._id = chunk._id;
      return doc;
    };
  }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongoOldNewItems.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/converter/mongoOldNewItems.js                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  MongoOldNewItems: () => MongoOldNewItems
});
let MongoOldNew;
module.link("./mongoOldNew", {
  MongoOldNew(v) {
    MongoOldNew = v;
  }

}, 0);

class MongoOldNewItems extends MongoOldNew {
  constructor(mongouOld, colOld, mongouNew, colNew) {
    super(mongouOld, mongouNew);
    this.title = 'migration of mongo items from old to new';
    this.colOld = colOld;
    this.colNew = colNew;

    this.convert = chunk => {
      // 在庫の変換
      const stock = chunk.stock.map(element => {
        const resElement = {};
        resElement.quantity = element.quantity;

        switch (element.delivery_date_id) {
          case 1:
            resElement.leadtime = 3;
            break;

          case 2:
            resElement.leadtime = 3;
            break;

          case 3:
            resElement.leadtime = 4;
            break;

          case 4:
            resElement.leadtime = 5;
            break;

          case 5:
            resElement.leadtime = 14;
            break;

          case 6:
            resElement.leadtime = 21;
            break;

          case 7:
            resElement.leadtime = -1;
            break;

          case 8:
            resElement.leadtime = -1;
            break;

          case 9:
            resElement.leadtime = -1;
            break;

          case 10:
            resElement.leadtime = 0;
            break;

          case 11:
            resElement.leadtime = 1;
            break;

          default:
            resElement.leadtime = -1;
        }

        switch (element.warehouse_id) {
          case 1:
            resElement.warehouse = 'ジェイラインジャパン';
            resElement.leadtime = 1;
            break;

          case 2:
            resElement.warehouse = '韓国';
            resElement.leadtime = 21;
            break;

          case 3:
            resElement.warehouse = 'コミネ';
            resElement.leadtime = 3;
            break;

          case 4:
            resElement.warehouse = 'ストラット';
            resElement.leadtime = 3;
            break;

          case 5:
            resElement.warehouse = 'お取寄せ';
            resElement.leadtime = -1;
            break;

          default:
            resElement.warehouse = '';
            resElement.leadtime = -1;
        }

        return resElement;
      }); // 配送方法の変換

      let delivery;

      switch (chunk.postage.id) {
        case 1:
          delivery = ['宅配便'];
          break;

        case 2:
          delivery = ['宅配便', 'ゆうパケット'];
          break;

        default:
          delivery = [];
      } // ドキュメントの構成


      const doc = {
        _id: chunk._id,
        meta: {
          updateTime: Date.now()
        },
        data: {
          name: chunk.name,
          jan: Math.floor(chunk.jan_code),
          jline: chunk.jline_code,
          retailPrice: chunk.retail_price,
          rate: chunk.rate,
          supplier: chunk.maker,
          brand: chunk.maker,
          stock,
          delivery
        }
      };
      return doc;
    };
  }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"data":{"mongo.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/data/mongo.js                                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  Mongo: () => Mongo
});
let fs;
module.link("fs-extra", {
  default(v) {
    fs = v;
  }

}, 0);
let iconv;
module.link("iconv-lite", {
  default(v) {
    iconv = v;
  }

}, 1);
let csv;
module.link("csv", {
  default(v) {
    csv = v;
  }

}, 2);
let Writable;
module.link("stream", {
  Writable(v) {
    Writable = v;
  }

}, 3);
let Meta;
module.link("../shared/meteorMongo/meta", {
  default(v) {
    Meta = v;
  }

}, 4);

class Mongo {
  /**
   *
   *
   * @static
   * @param {String} file
   * @param {import('mongodb').Collection} mc
   * @returns
   * @memberof Mongo
   */
  static importCsv(file, mc) {
    return Promise.asyncApply(() => {
      const read = fs.createReadStream(file);
      const write = new Writable({
        objectMode: true,

        write(chunk, encoding, callback) {
          return Promise.asyncApply(() => {
            // use meta form for document
            const doc = Meta.wrap(chunk); // insert to mongo collection

            try {
              Promise.await(mc.insert(doc));
            } catch (err) {
              callback(err);
            } // done correctly


            callback();
          });
        }

      });
      return new Promise((resolve, reject) => {
        read.pipe(iconv.decodeStream('SJIS')).pipe(iconv.encodeStream('UTF-8')).pipe(csv.parse({
          columns: true
        })).pipe(write).on('finish', () => {
          resolve();
        }).on('error', err => {
          reject(err);
        });
      });
    });
  }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"requet":{"request.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/requet/request.js                                                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  RequestManager: () => RequestManager
});
let Request;
module.link("../collections/request", {
  Request(v) {
    Request = v;
  }

}, 0);

class RequestManager {
  constructor(title, message) {
    this.id = Request.insert({
      title,
      message,
      startTime: Date.now(),
      endTime: null
    });
  }

  end(message) {
    Request.update(this.id, {
      $set: {
        message,
        endTime: Date.now()
      }
    });
  }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"service":{"itemRobot.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/service/itemRobot.js                                                                                     //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  default: () => ItemRobot
});
let ImportIrVARIABLES;
module.link("../collections/importIr", {
  ImportIrVARIABLES(v) {
    ImportIrVARIABLES = v;
  }

}, 0);
let Mongo;
module.link("../data/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);

class ItemRobot {
  static importAll() {
    return Promise.asyncApply(() => {
      Promise.await(ItemRobot.importAllCsv());
    });
  }

  static importAllCsv() {
    return Promise.asyncApply(() => {
      const max = ImportIrVARIABLES.ite.length;
      let count = 0;
      Promise.await(new Promise(resolve => {
        ImportIrVARIABLES.ite.forEach(e => Promise.asyncApply(() => {
          Promise.await(ItemRobot.importCsv2Mongo(e.mongocoll, `${ImportIrVARIABLES.workdir}/${e.csvfile}`));
          count += 1;

          if (count === max) {
            resolve();
          }
        }));
      }));
    });
  }

  static importCsv2Mongo(mongoCol, csvFile) {
    return Promise.asyncApply(() => {
      Promise.await(mongoCol.remove());
      Promise.await(Mongo.importCsv(csvFile, mongoCol));
    });
  }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"import.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/import.js                                                                                                //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.link("./vender/import");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"config.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/config.js                                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  ConfigManager: () => ConfigManager
});
let Config;
module.link("../imports/collections/config", {
  Config(v) {
    Config = v;
  }

}, 0);

class ConfigManager {
  static get() {
    const config = Config.findOne();
    return config;
  }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"file.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/file.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let fs;
module.link("fs-extra", {
  default(v) {
    fs = v;
  }

}, 1);
Meteor.methods({
  /**
   *
   * @param {*} dir
   * @param {*} fileName
   * @param {ArrayBuffer} base64Data
   */
  'file.upload'(dir, fileName, base64Data) {
    return Promise.asyncApply(() => {
      const fullpath = `${dir}/${fileName}`;
      Promise.await(fs.mkdirs(dir)); // convert base64 to buffer.

      const chunk = Buffer.from(base64Data, 'base64');
      const res = Promise.await(fs.writeFile(fullpath, chunk));
      return res;
    });
  },

  'file.stat'(fileName) {
    return Promise.asyncApply(() => {
      let stat;

      try {
        stat = Promise.await(fs.stat(fileName));
      } catch (e) {
        throw new Meteor.Error(e);
      }

      return stat;
    });
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"importIr.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/importIr.js                                                                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ItemRobot;
module.link("../imports/service/itemRobot", {
  default(v) {
    ItemRobot = v;
  }

}, 1);
let ImportIrItem, ImportIrSelection, ImportIrVARIABLES;
module.link("../imports/collections/importIr", {
  ImportIrItem(v) {
    ImportIrItem = v;
  },

  ImportIrSelection(v) {
    ImportIrSelection = v;
  },

  ImportIrVARIABLES(v) {
    ImportIrVARIABLES = v;
  }

}, 2);
Meteor.methods({
  'importIr.import'() {
    ItemRobot.importAll();
    return true;
  },

  'importIr.stat'() {
    const stat = {};
    ImportIrVARIABLES.ite.forEach(e => {
      const obj = {};
      obj.count = e.mongoCollMeteor.find().count();
      stat[e.symbol] = obj;
    });
    return stat;
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"migration.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/migration.js                                                                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let MongoOldNewItems;
module.link("../imports/converter/mongoOldNewItems", {
  MongoOldNewItems(v) {
    MongoOldNewItems = v;
  }

}, 1);
let ConfigManager;
module.link("./config", {
  ConfigManager(v) {
    ConfigManager = v;
  }

}, 2);
let RequestManager;
module.link("../imports/requet/request", {
  RequestManager(v) {
    RequestManager = v;
  }

}, 3);
let MongoOldNewExhib;
module.link("../imports/converter/mongoOldNewExhib", {
  MongoOldNewExhib(v) {
    MongoOldNewExhib = v;
  }

}, 4);

class Instance {
  static get() {
    const instance = {};
    const config = ConfigManager.get();
    instance.config = config;
    const mongouNew = `mongodb://${config.mongoItems.host}:${config.mongoItems.port}/${config.mongoItems.db}`;
    const mongouOld = `mongodb://${config.legacy.mongoItems.host}:${config.legacy.mongoItems.port}/${config.legacy.mongoItems.db}`;
    instance.mongoOldNewItems = new MongoOldNewItems(mongouOld, 'products', mongouNew, 'items');
    instance.mongoOldNewExhib = new MongoOldNewExhib(mongouOld, 'items', mongouNew, 'exhib');
    return instance;
  }

}

Meteor.methods({
  'migration.mongoOldNew.items.count'() {
    return Promise.asyncApply(() => {
      const instance = Instance.get();
      const number = Promise.await(instance.mongoOldNewItems.countImportCandidate());
      return number;
    });
  },

  'migration.mongoOldNew.items'() {
    const instance = Instance.get();
    const rm = new RequestManager('商品情報を mongo 旧から新データベースへ', '開始しました。');
    Meteor.defer(() => Promise.asyncApply(() => {
      const res = Promise.await(instance.mongoOldNewItems.migrate());
      rm.end(`${res}件のデータを移行しました。`);
    }));
    return 'mongo 旧から新データベースへの商品情報移行を開始しました。';
  },

  'migration.mongoOldNew.exhib.count'() {
    return Promise.asyncApply(() => {
      const instance = Instance.get();
      const number = Promise.await(instance.mongoOldNewExhib.countImportCandidate());
      return number;
    });
  },

  'migration.mongoOldNew.exhib'() {
    const instance = Instance.get();
    const rm = new RequestManager('出品情報を mongo 旧から新データベースへ', '開始しました。');
    Meteor.defer(() => Promise.asyncApply(() => {
      const res = Promise.await(instance.mongoOldNewExhib.migrate());
      rm.end(`${res}件のデータを移行しました。`);
    }));
    return 'mongo 旧から新データベースへの出品情報移行を開始しました。';
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/mongo.js                                                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let MongoClient;
module.link("mongodb", {
  MongoClient(v) {
    MongoClient = v;
  }

}, 1);
Meteor.methods({
  'mongo.connect.test'(mongoConnectDoc) {
    return Promise.asyncApply(() => {
      let dbclient;

      try {
        dbclient = Promise.await(MongoClient.connect(`mongodb://${mongoConnectDoc.host}:${mongoConnectDoc.port}`, {
          useNewUrlParser: true
        }));
        const db = dbclient.db(mongoConnectDoc.db);
        const dbinfo = Promise.await(db.listCollections().toArray());
        return dbinfo;
      } catch (e) {
        if (e.name) {
          throw new Meteor.Error(e.name, e.message);
        }

        throw e;
      } finally {
        if (dbclient) dbclient.close();
      }
    });
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/mysql.js                                                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let mysql;
module.link("mysql", {
  default(v) {
    mysql = v;
  }

}, 1);
Meteor.methods({
  'mysql.connect.test'(mysqlcred) {
    const con = mysql.createConnection(mysqlcred);
    Meteor.wrapAsync(mcb => {
      con.connect(err => {
        mcb(err);
      });
    })();
    const res = Meteor.wrapAsync(mcb => {
      con.query(`select * from information_schema.SCHEMATA where SCHEMA_NAME="${mysqlcred.database}"`, (err, results) => {
        mcb(err, results);
      });
    })();
    con.end();
    const resString = JSON.stringify(res);

    if (resString === '[]') {
      throw new Meteor.Error('データベースが指定されていません。');
    }

    return JSON.stringify(res);
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"request.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/request.js                                                                                                //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let RequestManager;
module.link("../imports/requet/request", {
  RequestManager(v) {
    RequestManager = v;
  }

}, 1);
Meteor.methods({
  'request.test'() {
    const rm = new RequestManager('Request テスト', '開始しました');
    Meteor.setTimeout(() => {
      rm.end('終了しました');
    }, 10000);
    return 'Request テスト 10秒後に終了します。';
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/main.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Config;
module.link("../imports/collections/config", {
  Config(v) {
    Config = v;
  }

}, 0);
let Items;
module.link("../imports/collections/items", {
  Items(v) {
    Items = v;
  }

}, 1);
module.link("../imports/collections/importIr");
module.link("../imports/import");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/server/config.js");
require("/server/file.js");
require("/server/importIr.js");
require("/server/migration.js");
require("/server/mongo.js");
require("/server/mysql.js");
require("/server/request.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy92ZW5kZXIvc3RydXQvaW1wb3J0TmV3L2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdmVuZGVyL3N0cnV0L2ltcG9ydE5ldy9pbXBvcnQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdmVuZGVyL3N0cnV0L2ltcG9ydE5ldy9tZXRob2QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdmVuZGVyL3N0cnV0L2ltcG9ydC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy92ZW5kZXIvaW1wb3J0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NoYXJlZC9tZXRlb3JNb25nby9tZXRhLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb25zL2NvbmZpZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9ucy9pbXBvcnRJci5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9ucy9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9ucy9yZXF1ZXN0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbnZlcnRlci9tb25nb09sZE5ldy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb252ZXJ0ZXIvbW9uZ29PbGROZXdFeGhpYi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb252ZXJ0ZXIvbW9uZ29PbGROZXdJdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9kYXRhL21vbmdvLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3JlcXVldC9yZXF1ZXN0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2UvaXRlbVJvYm90LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2ltcG9ydC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NvbmZpZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2ZpbGUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9pbXBvcnRJci5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21pZ3JhdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21vbmdvLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbXlzcWwuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9yZXF1ZXN0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJzdHJ1dE5ld0l0ZW1zIiwiTWV0ZW9yIiwibGluayIsInYiLCJNb25nbyIsIk1ldGEiLCJkZWZhdWx0IiwiQ29sbGVjdGlvbiIsImlkR2VuZXJhdGlvbiIsImlzU2VydmVyIiwicHVibGlzaCIsImZpbmQiLCJpbmplY3QiLCJtZXRob2RzIiwiZmlsZSIsInJlbW92ZSIsImltcG9ydENzdiIsInJhd0NvbGxlY3Rpb24iLCJtZXRlb3JNb25nb0NvbGxlY3Rpb24iLCJzZWxlY3RlZEl0ZW1zIiwiaGVscGVycyIsInRvZ2dsZSIsInNlbGVjdCIsIm1ldGEiLCJib29sIiwidXBkYXRlIiwiX2lkIiwiJHNldCIsImlzU2VsZWN0ZWQiLCJhbGxvdyIsImRvYyIsInVwZGF0ZVRpbWUiLCJEYXRlIiwibm93Iiwid3JhcCIsImRhdGEiLCJDb25maWciLCJjb3VudCIsImluc2VydCIsImxpbWl0IiwiSW1wb3J0SXJWQVJJQUJMRVMiLCJ3b3JrZGlyIiwiaXRlIiwic3ltYm9sIiwiY3N2ZmlsZSIsIm1vbmdvY29sbCIsIm1vbmdvQ29sbE1ldGVvciIsImZvckVhY2giLCJzdWJzY3JpYmVOYW1lIiwiSXRlbXMiLCJkZW55IiwiUmVxdWVzdCIsIk1vbmdvT2xkTmV3IiwiTW9uZ29DbGllbnQiLCJXcml0YWJsZSIsIlRyYW5zZm9ybSIsImNvbnN0cnVjdG9yIiwibW9uZ291T2xkIiwibW9uZ291TmV3IiwidGl0bGUiLCJnZXRPbGREYkNvbm5lY3QiLCJjbGllbnQiLCJ1c2VOZXdVcmxQYXJzZXIiLCJjb25uZWN0IiwiZ2V0TmV3RGJDb25uZWN0IiwiY291bnRJbXBvcnRDYW5kaWRhdGUiLCJwcm9taXNlIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJyZWFkQ2FuZGlkYXRlIiwicmVhZGFibGVJbXBvcnRDYW5kaWRhdGUiLCJvbiIsImVyciIsInJlc3VtZSIsIm1vbmdvY09sZCIsIm9sZERiIiwiZGIiLCJtb25nb2NOZXciLCJuZXdEYiIsInRmTm90RXhpc3QiLCJvYmplY3RNb2RlIiwidHJhbnNmb3JtIiwiY2h1bmsiLCJlbmMiLCJjYiIsImNvbGxlY3Rpb24iLCJjb2xOZXciLCJmaW5kT25lIiwicHJvamVjdGlvbiIsImZpbmFsIiwiY2xvc2UiLCJyZWFkYWJsZSIsImNvbE9sZCIsInByb2plY3QiLCJwaXBlIiwibWlncmF0ZSIsInJlYWQiLCJyZXZSZWFkIiwidGZEYXRhIiwicmVhZGFibGVPYmplY3RNb2RlIiwid3JpdGFibGVPYmplY3RNb2RlIiwiY29udmVydCIsInRmV3JpdGVNb25nb05ldyIsImNtciIsImluc2VydE9uZSIsIndyaXRlIiwiaW5zZXJ0ZWRDb3VudCIsIk1vbmdvT2xkTmV3RXhoaWIiLCJ1bmlxaWQiLCJiYXNlIiwibmFtZSIsIml0ZW0iLCJwcm9kdWN0IiwiZGVzY3JpcHRpb24iLCJpbWFnZXMiLCJkZWxpdmVyeSIsImphbiIsImphbl9jb2RlIiwiY2xhc3MxTmFtZSIsImNsYXNzMV9uYW1lIiwiY2xhc3MxVmFsdWUiLCJjbGFzczFfdmFsdWUiLCJjbGFzczJOYW1lIiwiY2xhc3MyX25hbWUiLCJjbGFzczJWYWx1ZSIsImNsYXNzMl92YWx1ZSIsInJldGFpbFByaWNlIiwicmV0YWlsX3ByaWNlIiwidGFnIiwicmFrdXRlbiIsIm1hbGwiLCJpdGVtVXJsIiwiSENob2ljZU5hbWUiLCJWQ2hvaWNlTmFtZSIsInlzaG9wIiwiaXRlbUNvZGUiLCJpdGVtX2NvZGUiLCJzdWJDb2RlIiwic3ViX2NvZGUiLCJ5YXVjdCIsInVpZCIsImNhdGVnb3J5IiwibWluUXVhbnRpdHkiLCJzaGFyYWt1U2hvcCIsInByb2R1Y3RfaWQiLCJwcm9kdWN0X2NsYXNzX2lkIiwicHJvZHVjdF9zdG9ja19pZCIsInByaWNlIiwid293bWEiLCJpdGVtTWFuYWdlbWVudElkIiwiT2JqZWN0Iiwia2V5cyIsImtleSIsIk1vbmdvT2xkTmV3SXRlbXMiLCJzdG9jayIsIm1hcCIsImVsZW1lbnQiLCJyZXNFbGVtZW50IiwicXVhbnRpdHkiLCJkZWxpdmVyeV9kYXRlX2lkIiwibGVhZHRpbWUiLCJ3YXJlaG91c2VfaWQiLCJ3YXJlaG91c2UiLCJwb3N0YWdlIiwiaWQiLCJNYXRoIiwiZmxvb3IiLCJqbGluZSIsImpsaW5lX2NvZGUiLCJyYXRlIiwic3VwcGxpZXIiLCJtYWtlciIsImJyYW5kIiwiZnMiLCJpY29udiIsImNzdiIsIm1jIiwiY3JlYXRlUmVhZFN0cmVhbSIsImVuY29kaW5nIiwiY2FsbGJhY2siLCJkZWNvZGVTdHJlYW0iLCJlbmNvZGVTdHJlYW0iLCJwYXJzZSIsImNvbHVtbnMiLCJSZXF1ZXN0TWFuYWdlciIsIm1lc3NhZ2UiLCJzdGFydFRpbWUiLCJlbmRUaW1lIiwiZW5kIiwiSXRlbVJvYm90IiwiaW1wb3J0QWxsIiwiaW1wb3J0QWxsQ3N2IiwibWF4IiwibGVuZ3RoIiwiZSIsImltcG9ydENzdjJNb25nbyIsIm1vbmdvQ29sIiwiY3N2RmlsZSIsIkNvbmZpZ01hbmFnZXIiLCJnZXQiLCJjb25maWciLCJkaXIiLCJmaWxlTmFtZSIsImJhc2U2NERhdGEiLCJmdWxscGF0aCIsIm1rZGlycyIsIkJ1ZmZlciIsImZyb20iLCJyZXMiLCJ3cml0ZUZpbGUiLCJzdGF0IiwiRXJyb3IiLCJJbXBvcnRJckl0ZW0iLCJJbXBvcnRJclNlbGVjdGlvbiIsIm9iaiIsIkluc3RhbmNlIiwiaW5zdGFuY2UiLCJtb25nb0l0ZW1zIiwiaG9zdCIsInBvcnQiLCJsZWdhY3kiLCJtb25nb09sZE5ld0l0ZW1zIiwibW9uZ29PbGROZXdFeGhpYiIsIm51bWJlciIsInJtIiwiZGVmZXIiLCJtb25nb0Nvbm5lY3REb2MiLCJkYmNsaWVudCIsImRiaW5mbyIsImxpc3RDb2xsZWN0aW9ucyIsInRvQXJyYXkiLCJteXNxbCIsIm15c3FsY3JlZCIsImNvbiIsImNyZWF0ZUNvbm5lY3Rpb24iLCJ3cmFwQXN5bmMiLCJtY2IiLCJxdWVyeSIsImRhdGFiYXNlIiwicmVzdWx0cyIsInJlc1N0cmluZyIsIkpTT04iLCJzdHJpbmdpZnkiLCJzZXRUaW1lb3V0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBQSxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDQyxlQUFhLEVBQUMsTUFBSUE7QUFBbkIsQ0FBZDtBQUFpRCxJQUFJQyxNQUFKO0FBQVdILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVU4sTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUUsSUFBSjtBQUFTUCxNQUFNLENBQUNJLElBQVAsQ0FBWSxrQ0FBWixFQUErQztBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDRSxRQUFJLEdBQUNGLENBQUw7QUFBTzs7QUFBbkIsQ0FBL0MsRUFBb0UsQ0FBcEU7QUFJL0ssTUFBTUgsYUFBYSxHQUFHLElBQUlJLEtBQUssQ0FBQ0csVUFBVixDQUFxQixlQUFyQixFQUFzQztBQUFFQyxjQUFZLEVBQUU7QUFBaEIsQ0FBdEMsQ0FBdEI7O0FBQ1AsSUFBSVAsTUFBTSxDQUFDUSxRQUFYLEVBQXFCO0FBQ25CUixRQUFNLENBQUNTLE9BQVAsQ0FBZSxlQUFmLEVBQWdDLE1BQU1WLGFBQWEsQ0FBQ1csSUFBZCxFQUF0QztBQUNEOztBQUNETixJQUFJLENBQUNPLE1BQUwsQ0FBWVosYUFBWixFOzs7Ozs7Ozs7OztBQ1JBRixNQUFNLENBQUNJLElBQVAsQ0FBWSxVQUFaO0FBQXdCSixNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEU7Ozs7Ozs7Ozs7O0FDQXhCLElBQUlELE1BQUo7QUFBV0gsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVTixNQUFNLENBQUNJLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBbEMsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSUgsYUFBSjtBQUFrQkYsTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRixlQUFhLENBQUNHLENBQUQsRUFBRztBQUFDSCxpQkFBYSxHQUFDRyxDQUFkO0FBQWdCOztBQUFsQyxDQUEzQixFQUErRCxDQUEvRDs7QUFJckosSUFBSUYsTUFBTSxDQUFDUSxRQUFYLEVBQXFCO0FBQ25CUixRQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNiOzs7OztBQUtBLHNCQUFtQkMsSUFBbkIsRUFBeUI7QUFDdkJkLG1CQUFhLENBQUNlLE1BQWQsQ0FBcUIsRUFBckI7QUFDQVgsV0FBSyxDQUFDWSxTQUFOLENBQWdCRixJQUFoQixFQUFzQmQsYUFBYSxDQUFDaUIsYUFBZCxFQUF0QjtBQUNEOztBQVRZLEdBQWY7QUFXRCxDOzs7Ozs7Ozs7OztBQ2hCRG5CLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLG9CQUFaLEU7Ozs7Ozs7Ozs7O0FDQUFKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGdCQUFaLEU7Ozs7Ozs7Ozs7O0FDQUFKLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNPLFNBQU8sRUFBQyxNQUFJRDtBQUFiLENBQWQ7O0FBRWUsTUFBTUEsSUFBTixDQUFXO0FBQ3hCOzs7Ozs7OztBQVFBLFNBQU9PLE1BQVAsQ0FBY00scUJBQWQsRUFBcUM7QUFDbkM7QUFDQUEseUJBQXFCLENBQUNDLGFBQXRCLEdBQXNDLE1BQU1ELHFCQUFxQixDQUFDUCxJQUF0QixDQUEyQjtBQUFFLHFCQUFlO0FBQWpCLEtBQTNCLENBQTVDLENBRm1DLENBSW5DOzs7QUFDQU8seUJBQXFCLENBQUNFLE9BQXRCLENBQThCO0FBQzVCQyxZQUFNLEdBQUc7QUFDUCxhQUFLQyxNQUFMLENBQVksQ0FBQyxLQUFLQyxJQUFMLENBQVVELE1BQXZCO0FBQ0QsT0FIMkI7O0FBSTVCQSxZQUFNLENBQUNFLElBQUQsRUFBTztBQUNYTiw2QkFBcUIsQ0FBQ08sTUFBdEIsQ0FDRTtBQUFFQyxhQUFHLEVBQUUsS0FBS0E7QUFBWixTQURGLEVBRUU7QUFBRUMsY0FBSSxFQUFFO0FBQUUsMkJBQWVIO0FBQWpCO0FBQVIsU0FGRjtBQUlBLGFBQUtELElBQUwsQ0FBVUQsTUFBVixHQUFtQkUsSUFBbkI7QUFDRCxPQVYyQjs7QUFXNUJJLGdCQUFVLEdBQUc7QUFDWCxlQUFPLEtBQUtMLElBQUwsQ0FBVUQsTUFBakI7QUFDRDs7QUFiMkIsS0FBOUIsRUFMbUMsQ0FxQm5DOztBQUNBSix5QkFBcUIsQ0FBQ1csS0FBdEIsQ0FBNEI7QUFDMUJKLFlBQU0sRUFBRSxNQUFNO0FBRFksS0FBNUI7QUFHRDtBQUVEOzs7Ozs7QUFJQSxTQUFPQSxNQUFQLENBQWNLLEdBQWQsRUFBbUI7QUFDakI7QUFDQTtBQUNBLFFBQUksT0FBT0EsR0FBRyxDQUFDUCxJQUFYLEtBQW9CLFdBQXhCLEVBQXFDO0FBQ25DTyxTQUFHLENBQUNQLElBQUosR0FBVyxFQUFYO0FBQ0Q7O0FBQ0RPLE9BQUcsQ0FBQ1AsSUFBSixDQUFTUSxVQUFULEdBQXNCQyxJQUFJLENBQUNDLEdBQUwsRUFBdEI7QUFDRDs7QUFFRCxTQUFPQyxJQUFQLENBQVlKLEdBQVosRUFBaUI7QUFDZixXQUFPO0FBQ0xQLFVBQUksRUFBRTtBQUNKUSxrQkFBVSxFQUFFQyxJQUFJLENBQUNDLEdBQUwsRUFEUjtBQUVKWCxjQUFNLEVBQUU7QUFGSixPQUREO0FBS0xhLFVBQUksRUFBRUw7QUFMRCxLQUFQO0FBT0Q7O0FBekR1QixDOzs7Ozs7Ozs7OztBQ0YxQmhDLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNxQyxRQUFNLEVBQUMsTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUluQyxNQUFKO0FBQVdILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVU4sTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFHdEcsTUFBTWlDLE1BQU0sR0FBRyxJQUFJaEMsS0FBSyxDQUFDRyxVQUFWLENBQXFCLFFBQXJCLEVBQStCO0FBQUVDLGNBQVksRUFBRTtBQUFoQixDQUEvQixDQUFmOztBQUVQLElBQUlQLE1BQU0sQ0FBQ1EsUUFBWCxFQUFxQjtBQUNuQixNQUFJLENBQUMyQixNQUFNLENBQUN6QixJQUFQLEdBQWMwQixLQUFkLEVBQUwsRUFBNEI7QUFDMUJELFVBQU0sQ0FBQ0UsTUFBUCxDQUFjLEVBQWQ7QUFDRDs7QUFDRHJDLFFBQU0sQ0FBQ1MsT0FBUCxDQUFlLFFBQWYsRUFBeUIsTUFBTTBCLE1BQU0sQ0FBQ3pCLElBQVAsQ0FBWSxFQUFaLEVBQWdCO0FBQUU0QixTQUFLLEVBQUU7QUFBVCxHQUFoQixDQUEvQjtBQUVBdEMsUUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYixvQkFBaUJpQixHQUFqQixFQUFzQjtBQUNwQk0sWUFBTSxDQUFDWCxNQUFQLENBQWMsRUFBZCxFQUFrQkssR0FBbEI7QUFDRDs7QUFIWSxHQUFmO0FBTUQsQzs7Ozs7Ozs7Ozs7QUNqQkRoQyxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDeUMsbUJBQWlCLEVBQUMsTUFBSUE7QUFBdkIsQ0FBZDtBQUF5RCxJQUFJdkMsTUFBSjtBQUFXSCxNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxLQUFKO0FBQVVOLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0UsT0FBSyxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsU0FBSyxHQUFDRCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlFLElBQUo7QUFBU1AsTUFBTSxDQUFDSSxJQUFQLENBQVksNEJBQVosRUFBeUM7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQ0UsUUFBSSxHQUFDRixDQUFMO0FBQU87O0FBQW5CLENBQXpDLEVBQThELENBQTlEO0FBSXZMLE1BQU1xQyxpQkFBaUIsR0FBRztBQUMvQkMsU0FBTyxFQUFFLGdCQURzQjtBQUUvQkMsS0FBRyxFQUFFLENBQ0g7QUFDRUMsVUFBTSxFQUFFLGdCQURWO0FBRUVDLFdBQU8sRUFBRSxhQUZYO0FBR0VDLGFBQVMsRUFBRSxJQUhiO0FBSUVDLG1CQUFlLEVBQUU7QUFKbkIsR0FERyxFQU9IO0FBQ0VILFVBQU0sRUFBRSxxQkFEVjtBQUVFQyxXQUFPLEVBQUUsbUJBRlg7QUFHRUMsYUFBUyxFQUFFLElBSGI7QUFJRUMsbUJBQWUsRUFBRTtBQUpuQixHQVBHLEVBYUg7QUFDRUgsVUFBTSxFQUFFLGdCQURWO0FBRUVDLFdBQU8sRUFBRSx1QkFGWDtBQUdFQyxhQUFTLEVBQUUsSUFIYjtBQUlFQyxtQkFBZSxFQUFFO0FBSm5CLEdBYkcsRUFtQkg7QUFDRUgsVUFBTSxFQUFFLGdCQURWO0FBRUVDLFdBQU8sRUFBRSxzQkFGWDtBQUdFQyxhQUFTLEVBQUUsSUFIYjtBQUlFQyxtQkFBZSxFQUFFO0FBSm5CLEdBbkJHLEVBeUJIO0FBQ0VILFVBQU0sRUFBRSxrQkFEVjtBQUVFQyxXQUFPLEVBQUUsbUJBRlg7QUFHRUMsYUFBUyxFQUFFLElBSGI7QUFJRUMsbUJBQWUsRUFBRTtBQUpuQixHQXpCRyxFQStCSDtBQUNFSCxVQUFNLEVBQUUsb0JBRFY7QUFFRUMsV0FBTyxFQUFFLGtCQUZYO0FBR0VDLGFBQVMsRUFBRSxJQUhiO0FBSUVDLG1CQUFlLEVBQUU7QUFKbkIsR0EvQkcsRUFxQ0g7QUFDRUgsVUFBTSxFQUFFLHlCQURWO0FBRUVDLFdBQU8sRUFBRSw0QkFGWDtBQUdFQyxhQUFTLEVBQUUsSUFIYjtBQUlFQyxtQkFBZSxFQUFFO0FBSm5CLEdBckNHLEVBMkNIO0FBQ0VILFVBQU0sRUFBRSx5QkFEVjtBQUVFQyxXQUFPLEVBQUUsMkJBRlg7QUFHRUMsYUFBUyxFQUFFLElBSGI7QUFJRUMsbUJBQWUsRUFBRTtBQUpuQixHQTNDRyxFQWlESDtBQUNFSCxVQUFNLEVBQUUsMkJBRFY7QUFFRUMsV0FBTyxFQUFFLHdCQUZYO0FBR0VDLGFBQVMsRUFBRSxJQUhiO0FBSUVDLG1CQUFlLEVBQUU7QUFKbkIsR0FqREc7QUFGMEIsQ0FBMUI7QUE2RFBOLGlCQUFpQixDQUFDRSxHQUFsQixDQUFzQkssT0FBdEIsQ0FBK0JMLEdBQUQsSUFBUztBQUNyQ0EsS0FBRyxDQUFDSSxlQUFKLEdBQXNCLElBQUkxQyxLQUFLLENBQUNHLFVBQVYsQ0FBcUJtQyxHQUFHLENBQUNDLE1BQXpCLEVBQWlDO0FBQUVuQyxnQkFBWSxFQUFFO0FBQWhCLEdBQWpDLENBQXRCO0FBQ0FrQyxLQUFHLENBQUNHLFNBQUosR0FBZ0I1QyxNQUFNLENBQUNRLFFBQVAsR0FBa0JpQyxHQUFHLENBQUNJLGVBQUosQ0FBb0I3QixhQUFwQixFQUFsQixHQUF3RCxJQUF4RTtBQUVBWixNQUFJLENBQUNPLE1BQUwsQ0FBWThCLEdBQUcsQ0FBQ0ksZUFBaEI7QUFFQUosS0FBRyxDQUFDSSxlQUFKLENBQW9CakIsS0FBcEIsQ0FBMEI7QUFDeEJTLFVBQU0sRUFBRSxNQUFNLElBRFU7QUFFeEJ2QixVQUFNLEVBQUUsTUFBTTtBQUZVLEdBQTFCOztBQUtBLE1BQUlkLE1BQU0sQ0FBQ1EsUUFBWCxFQUFxQjtBQUNuQlIsVUFBTSxDQUFDUyxPQUFQLENBQ0VnQyxHQUFHLENBQUNDLE1BRE4sRUFFRSxNQUFNRCxHQUFHLENBQUNJLGVBQUosQ0FBb0JuQyxJQUFwQixFQUZSO0FBSUQ7QUFDRixDQWpCRDs7QUFtQkEsSUFBSVYsTUFBTSxDQUFDUSxRQUFYLEVBQXFCO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBRUFSLFFBQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2I7Ozs7O0FBS0EsaUNBQThCbUMsYUFBOUIsRUFBNkM7QUFDM0NSLHVCQUFpQixDQUFDRSxHQUFsQixDQUFzQkssT0FBdEIsQ0FBK0JMLEdBQUQsSUFBUztBQUNyQyxZQUFJQSxHQUFHLENBQUNDLE1BQUosS0FBZUssYUFBbkIsRUFBa0M7QUFDaENOLGFBQUcsQ0FBQ0ksZUFBSixDQUFvQi9CLE1BQXBCLENBQTJCLEVBQTNCO0FBQ0Q7QUFDRixPQUpEO0FBS0Q7O0FBWlksR0FBZjtBQWNELEM7Ozs7Ozs7Ozs7O0FDeEdEakIsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ2tELE9BQUssRUFBQyxNQUFJQTtBQUFYLENBQWQ7QUFBaUMsSUFBSWhELE1BQUo7QUFBV0gsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVTixNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJRSxJQUFKO0FBQVNQLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLDRCQUFaLEVBQXlDO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNFLFFBQUksR0FBQ0YsQ0FBTDtBQUFPOztBQUFuQixDQUF6QyxFQUE4RCxDQUE5RDtBQUkvSixNQUFNOEMsS0FBSyxHQUFHLElBQUk3QyxLQUFLLENBQUNHLFVBQVYsQ0FBcUIsT0FBckIsRUFBOEI7QUFBRUMsY0FBWSxFQUFFO0FBQWhCLENBQTlCLENBQWQ7O0FBRVAsSUFBSVAsTUFBTSxDQUFDUSxRQUFYLEVBQXFCO0FBQ25CUixRQUFNLENBQUNTLE9BQVAsQ0FBZSxPQUFmLEVBQXdCLE1BQU11QyxLQUFLLENBQUN0QyxJQUFOLENBQVcsRUFBWCxDQUE5QjtBQUVBc0MsT0FBSyxDQUFDcEIsS0FBTixDQUFZO0FBQ1ZkLFVBQU0sRUFBRSxNQUFNO0FBREosR0FBWjtBQUlBa0MsT0FBSyxDQUFDQyxJQUFOLENBQVc7QUFDVFosVUFBTSxFQUFFLE1BQU0sSUFETDtBQUVUYixVQUFNLEVBQUUsTUFBTTtBQUZMLEdBQVg7QUFLQXhCLFFBQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2IsbUJBQWdCaUIsR0FBaEIsRUFBcUI7QUFDbkJ6QixVQUFJLENBQUNvQixNQUFMLENBQVlLLEdBQVo7QUFDQSxhQUFPbUIsS0FBSyxDQUFDWCxNQUFOLENBQWFSLEdBQWIsQ0FBUDtBQUNELEtBSlk7O0FBTWIsbUJBQWdCQSxHQUFoQixFQUFxQjtBQUNuQnpCLFVBQUksQ0FBQ29CLE1BQUwsQ0FBWUssR0FBWjtBQUNBLGFBQU9tQixLQUFLLENBQUN4QixNQUFOLENBQWFLLEdBQUcsQ0FBQ0osR0FBakIsRUFBc0JJLEdBQXRCLENBQVA7QUFDRDs7QUFUWSxHQUFmO0FBV0QsQzs7Ozs7Ozs7Ozs7QUM3QkRoQyxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDb0QsU0FBTyxFQUFDLE1BQUlBO0FBQWIsQ0FBZDtBQUFxQyxJQUFJbEQsTUFBSjtBQUFXSCxNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxLQUFKO0FBQVVOLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0UsT0FBSyxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsU0FBSyxHQUFDRCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBR3hHLE1BQU1nRCxPQUFPLEdBQUcsSUFBSS9DLEtBQUssQ0FBQ0csVUFBVixDQUFxQixTQUFyQixFQUFnQztBQUNyREMsY0FBWSxFQUFFO0FBRHVDLENBQWhDLENBQWhCOztBQUlQLElBQUlQLE1BQU0sQ0FBQ1EsUUFBWCxFQUFxQjtBQUNuQlIsUUFBTSxDQUFDUyxPQUFQLENBQWUsU0FBZixFQUEwQixNQUFNeUMsT0FBTyxDQUFDeEMsSUFBUixFQUFoQztBQUNELEM7Ozs7Ozs7Ozs7O0FDVERiLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNxRCxhQUFXLEVBQUMsTUFBSUE7QUFBakIsQ0FBZDtBQUE2QyxJQUFJQyxXQUFKO0FBQWdCdkQsTUFBTSxDQUFDSSxJQUFQLENBQVksU0FBWixFQUFzQjtBQUFDbUQsYUFBVyxDQUFDbEQsQ0FBRCxFQUFHO0FBQUNrRCxlQUFXLEdBQUNsRCxDQUFaO0FBQWM7O0FBQTlCLENBQXRCLEVBQXNELENBQXREO0FBQXlELElBQUltRCxRQUFKLEVBQWFDLFNBQWI7QUFBdUJ6RCxNQUFNLENBQUNJLElBQVAsQ0FBWSxRQUFaLEVBQXFCO0FBQUNvRCxVQUFRLENBQUNuRCxDQUFELEVBQUc7QUFBQ21ELFlBQVEsR0FBQ25ELENBQVQ7QUFBVyxHQUF4Qjs7QUFBeUJvRCxXQUFTLENBQUNwRCxDQUFELEVBQUc7QUFBQ29ELGFBQVMsR0FBQ3BELENBQVY7QUFBWTs7QUFBbEQsQ0FBckIsRUFBeUUsQ0FBekU7O0FBTXRJLE1BQU1pRCxXQUFOLENBQWtCO0FBQ3ZCSSxhQUFXLENBQUNDLFNBQUQsRUFBWUMsU0FBWixFQUF1QjtBQUNoQyxTQUFLQyxLQUFMLEdBQWEsdUJBQWI7QUFDQSxTQUFLRixTQUFMLEdBQWlCQSxTQUFqQjtBQUNBLFNBQUtDLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ0Q7O0FBRUtFLGlCQUFOO0FBQUEsb0NBQXdCO0FBQ3RCLFlBQU1DLE1BQU0saUJBQVMsSUFBSVIsV0FBSixDQUFnQixLQUFLSSxTQUFyQixFQUFnQztBQUFFSyx1QkFBZSxFQUFFO0FBQW5CLE9BQWhDLEVBQTJEQyxPQUEzRCxFQUFULENBQVo7QUFDQSxhQUFPRixNQUFQO0FBQ0QsS0FIRDtBQUFBOztBQUtNRyxpQkFBTjtBQUFBLG9DQUF3QjtBQUN0QixZQUFNSCxNQUFNLGlCQUFTLElBQUlSLFdBQUosQ0FBZ0IsS0FBS0ssU0FBckIsRUFBZ0M7QUFBRUksdUJBQWUsRUFBRTtBQUFuQixPQUFoQyxFQUEyREMsT0FBM0QsRUFBVCxDQUFaO0FBQ0EsYUFBT0YsTUFBUDtBQUNELEtBSEQ7QUFBQTs7QUFLTUksc0JBQU47QUFBQSxvQ0FBNkI7QUFDM0IsWUFBTUMsT0FBTyxHQUFHLElBQUlDLE9BQUosQ0FBWSxDQUFPQyxPQUFQLEVBQWdCQyxNQUFoQiw4QkFBMkI7QUFDckQsWUFBSWhDLEtBQUssR0FBRyxDQUFaO0FBRUEsY0FBTWlDLGFBQWEsaUJBQVMsS0FBS0MsdUJBQUwsRUFBVCxDQUFuQjtBQUNBRCxxQkFBYSxDQUNWRSxFQURILENBQ00sTUFETixFQUNjLE1BQU07QUFDaEJuQyxlQUFLLElBQUksQ0FBVDtBQUNELFNBSEgsRUFJR21DLEVBSkgsQ0FJTSxLQUpOLEVBSWEsTUFBTTtBQUNmSixpQkFBTyxDQUFDL0IsS0FBRCxDQUFQO0FBQ0QsU0FOSCxFQU9HbUMsRUFQSCxDQU9NLE9BUE4sRUFPZ0JDLEdBQUQsSUFBUztBQUNwQkosZ0JBQU0sQ0FBQ0ksR0FBRCxDQUFOO0FBQ0QsU0FUSDtBQVdBSCxxQkFBYSxDQUFDSSxNQUFkO0FBQ0QsT0FoQjJCLENBQVosQ0FBaEI7QUFrQkEsYUFBT1IsT0FBUDtBQUNELEtBcEJEO0FBQUE7O0FBc0JNSyx5QkFBTjtBQUFBLG9DQUFnQztBQUM5QixZQUFNSSxTQUFTLGlCQUFTLEtBQUtmLGVBQUwsRUFBVCxDQUFmO0FBQ0EsWUFBTWdCLEtBQUssR0FBR0QsU0FBUyxDQUFDRSxFQUFWLEVBQWQ7QUFFQSxZQUFNQyxTQUFTLGlCQUFTLEtBQUtkLGVBQUwsRUFBVCxDQUFmO0FBQ0EsWUFBTWUsS0FBSyxHQUFHRCxTQUFTLENBQUNELEVBQVYsRUFBZDtBQUVBLFlBQU1HLFVBQVUsR0FBRyxJQUFJekIsU0FBSixDQUFjO0FBQy9CMEIsa0JBQVUsRUFBRSxJQURtQjtBQUUvQkMsaUJBQVMsRUFBRSxDQUFPQyxLQUFQLEVBQWNDLEdBQWQsRUFBbUJDLEVBQW5CLDhCQUEwQjtBQUNuQztBQUNBLGNBQUlsRCxJQUFKOztBQUNBLGNBQUk7QUFDRkEsZ0JBQUksaUJBQVM0QyxLQUFLLENBQUNPLFVBQU4sQ0FBaUIsS0FBS0MsTUFBdEIsRUFDVkMsT0FEVSxDQUNGTCxLQUFLLENBQUN6RCxHQURKLEVBQ1M7QUFBRStELHdCQUFVLEVBQUU7QUFBRS9ELG1CQUFHLEVBQUU7QUFBUDtBQUFkLGFBRFQsQ0FBVCxDQUFKO0FBRUQsV0FIRCxDQUdFLE9BQU8rQyxHQUFQLEVBQVk7QUFDWlksY0FBRSxDQUFDWixHQUFELENBQUY7QUFDRDs7QUFFRCxjQUFJLENBQUN0QyxJQUFMLEVBQVc7QUFDVDtBQUNBa0QsY0FBRSxDQUFDLElBQUQsRUFBT0YsS0FBUCxDQUFGO0FBQ0QsV0FIRCxNQUdPO0FBQ0xFLGNBQUU7QUFDSDtBQUNGLFNBaEJVLENBRm9CO0FBbUIvQkssYUFBSyxFQUFTTCxFQUFQLDZCQUFjO0FBQ25CO0FBQ0Esd0JBQU1WLFNBQVMsQ0FBQ2dCLEtBQVYsRUFBTjtBQUNBLHdCQUFNYixTQUFTLENBQUNhLEtBQVYsRUFBTjtBQUNBTixZQUFFO0FBQ0gsU0FMTTtBQW5Cd0IsT0FBZCxDQUFuQjtBQTJCQSxZQUFNTyxRQUFRLEdBQUdoQixLQUFLLENBQUNVLFVBQU4sQ0FBaUIsS0FBS08sTUFBdEIsRUFDZGxGLElBRGMsR0FFZG1GLE9BRmMsR0FHZEMsSUFIYyxDQUdUZixVQUhTLENBQWpCO0FBS0EsYUFBT1ksUUFBUDtBQUNELEtBeENEO0FBQUE7O0FBMENNSSxTQUFOLENBQWNDLElBQWQ7QUFBQSxvQ0FBb0I7QUFDbEI7QUFDQSxVQUFJQyxPQUFPLEdBQUdELElBQWQ7O0FBQ0EsVUFBSSxDQUFDQyxPQUFMLEVBQWM7QUFBRUEsZUFBTyxpQkFBUyxLQUFLM0IsdUJBQUwsRUFBVCxDQUFQO0FBQWlEOztBQUVqRSxZQUFNNEIsTUFBTSxHQUFHLElBQUk1QyxTQUFKLENBQWM7QUFDM0I2QywwQkFBa0IsRUFBRSxJQURPO0FBRTNCQywwQkFBa0IsRUFBRSxJQUZPO0FBRzNCbkIsaUJBQVMsRUFBRSxDQUFPQyxLQUFQLEVBQWNDLEdBQWQsRUFBbUJDLEVBQW5CLDhCQUEwQjtBQUNuQztBQUNBLGdCQUFNbEQsSUFBSSxHQUFHLEtBQUttRSxPQUFMLENBQWFuQixLQUFiLENBQWI7QUFFQUUsWUFBRSxDQUFDLElBQUQsRUFBT2xELElBQVAsQ0FBRjtBQUNELFNBTFU7QUFIZ0IsT0FBZCxDQUFmLENBTGtCLENBZ0JsQjs7QUFDQSxZQUFNMkMsU0FBUyxpQkFBUyxLQUFLZCxlQUFMLEVBQVQsQ0FBZjtBQUNBLFlBQU1lLEtBQUssR0FBR0QsU0FBUyxDQUFDRCxFQUFWLEVBQWQ7QUFFQSxZQUFNMEIsZUFBZSxHQUFHLElBQUloRCxTQUFKLENBQWM7QUFDcEM2QywwQkFBa0IsRUFBRSxJQURnQjtBQUVwQ0MsMEJBQWtCLEVBQUUsSUFGZ0I7QUFHcENuQixpQkFBUyxFQUFFLENBQU9DLEtBQVAsRUFBY0MsR0FBZCxFQUFtQkMsRUFBbkIsOEJBQTBCO0FBQ25DLGNBQUltQixHQUFHLEdBQUcsSUFBVjs7QUFDQSxjQUFJO0FBQ0ZBLGVBQUcsaUJBQVN6QixLQUFLLENBQUNPLFVBQU4sQ0FBaUIsS0FBS0MsTUFBdEIsRUFBOEJrQixTQUE5QixDQUF3Q3RCLEtBQXhDLENBQVQsQ0FBSDtBQUNELFdBRkQsQ0FFRSxPQUFPVixHQUFQLEVBQVk7QUFDWlksY0FBRSxDQUFDWixHQUFELENBQUY7QUFDRDs7QUFDRFksWUFBRSxDQUFDLElBQUQsRUFBT21CLEdBQVAsQ0FBRjtBQUNELFNBUlUsQ0FIeUI7QUFZcENkLGFBQUssRUFBU0wsRUFBUCw2QkFBYztBQUNuQjtBQUNBLHdCQUFNUCxTQUFTLENBQUNhLEtBQVYsRUFBTjtBQUNBTixZQUFFO0FBQ0gsU0FKTTtBQVo2QixPQUFkLENBQXhCO0FBbUJBLFVBQUloRCxLQUFLLEdBQUcsQ0FBWjtBQUNBLFlBQU1xRSxLQUFLLEdBQUcsSUFBSXBELFFBQUosQ0FBYTtBQUN6QjJCLGtCQUFVLEVBQUUsSUFEYTtBQUV6QnlCLGFBQUssRUFBRSxDQUFDdkIsS0FBRCxFQUFRQyxHQUFSLEVBQWFDLEVBQWIsS0FBb0I7QUFDekJoRCxlQUFLLElBQUk4QyxLQUFLLENBQUN3QixhQUFmO0FBQ0F0QixZQUFFO0FBQ0g7QUFMd0IsT0FBYixDQUFkO0FBUUEsYUFBTyxJQUFJbEIsT0FBSixDQUFZLENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUN0QzZCLGVBQU8sQ0FDSkgsSUFESCxDQUNRSSxNQURSLEVBRUdKLElBRkgsQ0FFUVEsZUFGUixFQUdHUixJQUhILENBR1FXLEtBSFIsRUFJR2xDLEVBSkgsQ0FJTSxRQUpOLEVBSWdCLE1BQU07QUFDbEJKLGlCQUFPLENBQUMvQixLQUFELENBQVA7QUFDRCxTQU5ILEVBT0dtQyxFQVBILENBT00sT0FQTixFQU9nQkMsR0FBRCxJQUFTO0FBQ3BCSixnQkFBTSxDQUFDSSxHQUFELENBQU47QUFDRCxTQVRIO0FBVUQsT0FYTSxDQUFQO0FBWUQsS0E1REQ7QUFBQTs7QUFqRnVCLEM7Ozs7Ozs7Ozs7O0FDTnpCM0UsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQzZHLGtCQUFnQixFQUFDLE1BQUlBO0FBQXRCLENBQWQ7QUFBdUQsSUFBSUMsTUFBSjtBQUFXL0csTUFBTSxDQUFDSSxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDMEcsVUFBTSxHQUFDMUcsQ0FBUDtBQUFTOztBQUFyQixDQUFyQixFQUE0QyxDQUE1QztBQUErQyxJQUFJaUQsV0FBSjtBQUFnQnRELE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ2tELGFBQVcsQ0FBQ2pELENBQUQsRUFBRztBQUFDaUQsZUFBVyxHQUFDakQsQ0FBWjtBQUFjOztBQUE5QixDQUE1QixFQUE0RCxDQUE1RDtBQUErRCxJQUFJRSxJQUFKO0FBQVNQLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLDRCQUFaLEVBQXlDO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNFLFFBQUksR0FBQ0YsQ0FBTDtBQUFPOztBQUFuQixDQUF6QyxFQUE4RCxDQUE5RDs7QUFJbE0sTUFBTXlHLGdCQUFOLFNBQStCeEQsV0FBL0IsQ0FBMkM7QUFDaERJLGFBQVcsQ0FBQ0MsU0FBRCxFQUFZb0MsTUFBWixFQUFvQm5DLFNBQXBCLEVBQStCNkIsTUFBL0IsRUFBdUM7QUFDaEQsVUFBTTlCLFNBQU4sRUFBaUJDLFNBQWpCO0FBQ0EsU0FBS0MsS0FBTCxHQUFhLG9EQUFiO0FBRUEsU0FBS2tDLE1BQUwsR0FBY0EsTUFBZDtBQUNBLFNBQUtOLE1BQUwsR0FBY0EsTUFBZDs7QUFFQSxTQUFLZSxPQUFMLEdBQWdCbkIsS0FBRCxJQUFXO0FBQ3hCO0FBRUE7QUFDQSxZQUFNMkIsSUFBSSxHQUFHO0FBQ1huRCxhQUFLLEVBQUV3QixLQUFLLENBQUM0QixJQURGO0FBRVhDLFlBQUksRUFBRTdCLEtBQUssQ0FBQzhCLE9BRkQ7QUFHWEMsbUJBQVcsRUFBRS9CLEtBQUssQ0FBQytCLFdBSFI7QUFJWEMsY0FBTSxFQUFFaEMsS0FBSyxDQUFDZ0MsTUFKSDtBQUtYQyxnQkFBUSxFQUFFakMsS0FBSyxDQUFDaUMsUUFMTDtBQU1YQyxXQUFHLEVBQUVsQyxLQUFLLENBQUNtQyxRQU5BO0FBT1hDLGtCQUFVLEVBQUVwQyxLQUFLLENBQUNxQyxXQVBQO0FBUVhDLG1CQUFXLEVBQUV0QyxLQUFLLENBQUN1QyxZQVJSO0FBU1hDLGtCQUFVLEVBQUV4QyxLQUFLLENBQUN5QyxXQVRQO0FBVVhDLG1CQUFXLEVBQUUxQyxLQUFLLENBQUMyQyxZQVZSO0FBV1hDLG1CQUFXLEVBQUU1QyxLQUFLLENBQUM2QyxZQVhSO0FBWVhDLFdBQUcsRUFBRTlDLEtBQUssQ0FBQzhDLEdBWkE7QUFhWHRDLGFBQUssRUFBRVIsS0FBSyxDQUFDUTtBQWJGLE9BQWIsQ0FKd0IsQ0FvQnhCOztBQUNBLFlBQU11QyxPQUFPLEdBQUcvQyxLQUFLLENBQUNnRCxJQUFOLENBQVdELE9BQVgsR0FDWjtBQUNBRSxlQUFPLEVBQUVqRCxLQUFLLENBQUNnRCxJQUFOLENBQVdELE9BQVgsQ0FBbUJFLE9BRDVCO0FBRUFDLG1CQUFXLEVBQUVsRCxLQUFLLENBQUNnRCxJQUFOLENBQVdELE9BQVgsQ0FBbUJHLFdBRmhDO0FBR0FDLG1CQUFXLEVBQUVuRCxLQUFLLENBQUNnRCxJQUFOLENBQVdELE9BQVgsQ0FBbUJJO0FBSGhDLE9BRFksR0FNWixJQU5KLENBckJ3QixDQTZCeEI7O0FBQ0EsWUFBTUMsS0FBSyxHQUFHcEQsS0FBSyxDQUFDZ0QsSUFBTixDQUFXSSxLQUFYLEdBQ1Y7QUFDQUMsZ0JBQVEsRUFBRXJELEtBQUssQ0FBQ2dELElBQU4sQ0FBV0ksS0FBWCxDQUFpQkUsU0FEM0I7QUFFQUMsZUFBTyxFQUFFdkQsS0FBSyxDQUFDZ0QsSUFBTixDQUFXSSxLQUFYLENBQWlCSTtBQUYxQixPQURVLEdBS1YsSUFMSixDQTlCd0IsQ0FxQ3hCOztBQUNBLFlBQU1DLEtBQUssR0FBR3pELEtBQUssQ0FBQ2dELElBQU4sQ0FBV1MsS0FBWCxHQUNWO0FBQ0FDLFdBQUcsRUFBRWhDLE1BQU0sRUFEWDtBQUVBaUMsZ0JBQVEsRUFBRTNELEtBQUssQ0FBQ2dELElBQU4sQ0FBV1MsS0FBWCxDQUFpQkUsUUFGM0I7QUFHQUMsbUJBQVcsRUFBRTVELEtBQUssQ0FBQ2dELElBQU4sQ0FBV1MsS0FBWCxDQUFpQkc7QUFIOUIsT0FEVSxHQU1WLElBTkosQ0F0Q3dCLENBOEN4Qjs7QUFDQSxZQUFNQyxXQUFXLEdBQUc3RCxLQUFLLENBQUNnRCxJQUFOLENBQVdhLFdBQVgsR0FDaEI7QUFDQUMsa0JBQVUsRUFBRTlELEtBQUssQ0FBQ2dELElBQU4sQ0FBV2EsV0FBWCxDQUF1QkMsVUFEbkM7QUFFQUMsd0JBQWdCLEVBQUUvRCxLQUFLLENBQUNnRCxJQUFOLENBQVdhLFdBQVgsQ0FBdUJFLGdCQUZ6QztBQUdBQyx3QkFBZ0IsRUFBRWhFLEtBQUssQ0FBQ2dELElBQU4sQ0FBV2EsV0FBWCxDQUF1QkcsZ0JBSHpDO0FBSUFDLGFBQUssRUFBRWpFLEtBQUssQ0FBQ2dELElBQU4sQ0FBV2EsV0FBWCxDQUF1Qkk7QUFKOUIsT0FEZ0IsR0FPaEIsSUFQSixDQS9Dd0IsQ0F3RHhCOztBQUNBLFlBQU1DLEtBQUssR0FBR2xFLEtBQUssQ0FBQ2dELElBQU4sQ0FBV2tCLEtBQVgsR0FDVjtBQUNBaEIsbUJBQVcsRUFBRWxELEtBQUssQ0FBQ2dELElBQU4sQ0FBV2tCLEtBQVgsQ0FBaUJoQixXQUQ5QjtBQUVBQyxtQkFBVyxFQUFFbkQsS0FBSyxDQUFDZ0QsSUFBTixDQUFXa0IsS0FBWCxDQUFpQmYsV0FGOUI7QUFHQUUsZ0JBQVEsRUFBRXJELEtBQUssQ0FBQ2dELElBQU4sQ0FBV2tCLEtBQVgsQ0FBaUJiLFFBSDNCO0FBSUFjLHdCQUFnQixFQUFFbkUsS0FBSyxDQUFDZ0QsSUFBTixDQUFXa0IsS0FBWCxDQUFpQkM7QUFKbkMsT0FEVSxHQU9WLElBUEo7QUFTQSxZQUFNbkgsSUFBSSxHQUFHO0FBQ1gyRSxZQURXO0FBRVhvQixlQUZXO0FBR1hLLGFBSFc7QUFJWEssYUFKVztBQUtYSSxtQkFMVztBQU1YSztBQU5XLE9BQWI7QUFTQUUsWUFBTSxDQUFDQyxJQUFQLENBQVlySCxJQUFaLEVBQWtCWSxPQUFsQixDQUNHMEcsR0FBRCxJQUFTO0FBQ1B0SCxZQUFJLENBQUNzSCxHQUFELENBQUosR0FBWXBKLElBQUksQ0FBQzZCLElBQUwsQ0FBVUMsSUFBSSxDQUFDc0gsR0FBRCxDQUFkLENBQVo7QUFDRCxPQUhILEVBM0V3QixDQWdGeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxZQUFNM0gsR0FBRyxHQUFHekIsSUFBSSxDQUFDNkIsSUFBTCxDQUFVQyxJQUFWLENBQVo7QUFDQUwsU0FBRyxDQUFDSixHQUFKLEdBQVV5RCxLQUFLLENBQUN6RCxHQUFoQjtBQUVBLGFBQU9JLEdBQVA7QUFDRCxLQTdGRDtBQThGRDs7QUF0RytDLEM7Ozs7Ozs7Ozs7O0FDSmxEaEMsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQzJKLGtCQUFnQixFQUFDLE1BQUlBO0FBQXRCLENBQWQ7QUFBdUQsSUFBSXRHLFdBQUo7QUFBZ0J0RCxNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNrRCxhQUFXLENBQUNqRCxDQUFELEVBQUc7QUFBQ2lELGVBQVcsR0FBQ2pELENBQVo7QUFBYzs7QUFBOUIsQ0FBNUIsRUFBNEQsQ0FBNUQ7O0FBRWhFLE1BQU11SixnQkFBTixTQUErQnRHLFdBQS9CLENBQTJDO0FBQ2hESSxhQUFXLENBQUNDLFNBQUQsRUFBWW9DLE1BQVosRUFBb0JuQyxTQUFwQixFQUErQjZCLE1BQS9CLEVBQXVDO0FBQ2hELFVBQU05QixTQUFOLEVBQWlCQyxTQUFqQjtBQUNBLFNBQUtDLEtBQUwsR0FBYSwwQ0FBYjtBQUVBLFNBQUtrQyxNQUFMLEdBQWNBLE1BQWQ7QUFDQSxTQUFLTixNQUFMLEdBQWNBLE1BQWQ7O0FBRUEsU0FBS2UsT0FBTCxHQUFnQm5CLEtBQUQsSUFBVztBQUN4QjtBQUNBLFlBQU13RSxLQUFLLEdBQUd4RSxLQUFLLENBQUN3RSxLQUFOLENBQVlDLEdBQVosQ0FBaUJDLE9BQUQsSUFBYTtBQUN6QyxjQUFNQyxVQUFVLEdBQUcsRUFBbkI7QUFDQUEsa0JBQVUsQ0FBQ0MsUUFBWCxHQUFzQkYsT0FBTyxDQUFDRSxRQUE5Qjs7QUFDQSxnQkFBUUYsT0FBTyxDQUFDRyxnQkFBaEI7QUFDRSxlQUFLLENBQUw7QUFDRUYsc0JBQVUsQ0FBQ0csUUFBWCxHQUFzQixDQUF0QjtBQUNBOztBQUNGLGVBQUssQ0FBTDtBQUNFSCxzQkFBVSxDQUFDRyxRQUFYLEdBQXNCLENBQXRCO0FBQ0E7O0FBQ0YsZUFBSyxDQUFMO0FBQ0VILHNCQUFVLENBQUNHLFFBQVgsR0FBc0IsQ0FBdEI7QUFDQTs7QUFDRixlQUFLLENBQUw7QUFDRUgsc0JBQVUsQ0FBQ0csUUFBWCxHQUFzQixDQUF0QjtBQUNBOztBQUNGLGVBQUssQ0FBTDtBQUNFSCxzQkFBVSxDQUFDRyxRQUFYLEdBQXNCLEVBQXRCO0FBQ0E7O0FBQ0YsZUFBSyxDQUFMO0FBQ0VILHNCQUFVLENBQUNHLFFBQVgsR0FBc0IsRUFBdEI7QUFDQTs7QUFDRixlQUFLLENBQUw7QUFDRUgsc0JBQVUsQ0FBQ0csUUFBWCxHQUFzQixDQUFDLENBQXZCO0FBQ0E7O0FBQ0YsZUFBSyxDQUFMO0FBQ0VILHNCQUFVLENBQUNHLFFBQVgsR0FBc0IsQ0FBQyxDQUF2QjtBQUNBOztBQUNGLGVBQUssQ0FBTDtBQUNFSCxzQkFBVSxDQUFDRyxRQUFYLEdBQXNCLENBQUMsQ0FBdkI7QUFDQTs7QUFDRixlQUFLLEVBQUw7QUFDRUgsc0JBQVUsQ0FBQ0csUUFBWCxHQUFzQixDQUF0QjtBQUNBOztBQUNGLGVBQUssRUFBTDtBQUNFSCxzQkFBVSxDQUFDRyxRQUFYLEdBQXNCLENBQXRCO0FBQ0E7O0FBQ0Y7QUFBU0gsc0JBQVUsQ0FBQ0csUUFBWCxHQUFzQixDQUFDLENBQXZCO0FBbENYOztBQW9DQSxnQkFBUUosT0FBTyxDQUFDSyxZQUFoQjtBQUNFLGVBQUssQ0FBTDtBQUNFSixzQkFBVSxDQUFDSyxTQUFYLEdBQXVCLFlBQXZCO0FBQ0FMLHNCQUFVLENBQUNHLFFBQVgsR0FBc0IsQ0FBdEI7QUFDQTs7QUFDRixlQUFLLENBQUw7QUFDRUgsc0JBQVUsQ0FBQ0ssU0FBWCxHQUF1QixJQUF2QjtBQUNBTCxzQkFBVSxDQUFDRyxRQUFYLEdBQXNCLEVBQXRCO0FBQ0E7O0FBQ0YsZUFBSyxDQUFMO0FBQ0VILHNCQUFVLENBQUNLLFNBQVgsR0FBdUIsS0FBdkI7QUFDQUwsc0JBQVUsQ0FBQ0csUUFBWCxHQUFzQixDQUF0QjtBQUNBOztBQUNGLGVBQUssQ0FBTDtBQUNFSCxzQkFBVSxDQUFDSyxTQUFYLEdBQXVCLE9BQXZCO0FBQ0FMLHNCQUFVLENBQUNHLFFBQVgsR0FBc0IsQ0FBdEI7QUFDQTs7QUFDRixlQUFLLENBQUw7QUFDRUgsc0JBQVUsQ0FBQ0ssU0FBWCxHQUF1QixNQUF2QjtBQUNBTCxzQkFBVSxDQUFDRyxRQUFYLEdBQXNCLENBQUMsQ0FBdkI7QUFDQTs7QUFDRjtBQUNFSCxzQkFBVSxDQUFDSyxTQUFYLEdBQXVCLEVBQXZCO0FBQ0FMLHNCQUFVLENBQUNHLFFBQVgsR0FBc0IsQ0FBQyxDQUF2QjtBQXZCSjs7QUF5QkEsZUFBT0gsVUFBUDtBQUNELE9BakVhLENBQWQsQ0FGd0IsQ0FvRXhCOztBQUNBLFVBQUkxQyxRQUFKOztBQUNBLGNBQVFqQyxLQUFLLENBQUNpRixPQUFOLENBQWNDLEVBQXRCO0FBQ0UsYUFBSyxDQUFMO0FBQ0VqRCxrQkFBUSxHQUFHLENBQUMsS0FBRCxDQUFYO0FBQ0E7O0FBQ0YsYUFBSyxDQUFMO0FBQ0VBLGtCQUFRLEdBQUcsQ0FBQyxLQUFELEVBQVEsUUFBUixDQUFYO0FBQ0E7O0FBQ0Y7QUFBU0Esa0JBQVEsR0FBRyxFQUFYO0FBUFgsT0F0RXdCLENBK0V4Qjs7O0FBQ0EsWUFBTXRGLEdBQUcsR0FBRztBQUNWSixXQUFHLEVBQUV5RCxLQUFLLENBQUN6RCxHQUREO0FBRVZILFlBQUksRUFBRTtBQUNKUSxvQkFBVSxFQUFFQyxJQUFJLENBQUNDLEdBQUw7QUFEUixTQUZJO0FBS1ZFLFlBQUksRUFBRTtBQUNKNEUsY0FBSSxFQUFFNUIsS0FBSyxDQUFDNEIsSUFEUjtBQUVKTSxhQUFHLEVBQUVpRCxJQUFJLENBQUNDLEtBQUwsQ0FBV3BGLEtBQUssQ0FBQ21DLFFBQWpCLENBRkQ7QUFHSmtELGVBQUssRUFBRXJGLEtBQUssQ0FBQ3NGLFVBSFQ7QUFJSjFDLHFCQUFXLEVBQUU1QyxLQUFLLENBQUM2QyxZQUpmO0FBS0owQyxjQUFJLEVBQUV2RixLQUFLLENBQUN1RixJQUxSO0FBTUpDLGtCQUFRLEVBQUV4RixLQUFLLENBQUN5RixLQU5aO0FBT0pDLGVBQUssRUFBRTFGLEtBQUssQ0FBQ3lGLEtBUFQ7QUFRSmpCLGVBUkk7QUFTSnZDO0FBVEk7QUFMSSxPQUFaO0FBaUJBLGFBQU90RixHQUFQO0FBQ0QsS0FsR0Q7QUFtR0Q7O0FBM0crQyxDOzs7Ozs7Ozs7OztBQ0ZsRGhDLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNLLE9BQUssRUFBQyxNQUFJQTtBQUFYLENBQWQ7QUFBaUMsSUFBSTBLLEVBQUo7QUFBT2hMLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFVBQVosRUFBdUI7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQzJLLE1BQUUsR0FBQzNLLENBQUg7QUFBSzs7QUFBakIsQ0FBdkIsRUFBMEMsQ0FBMUM7QUFBNkMsSUFBSTRLLEtBQUo7QUFBVWpMLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQzRLLFNBQUssR0FBQzVLLENBQU47QUFBUTs7QUFBcEIsQ0FBekIsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSTZLLEdBQUo7QUFBUWxMLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLEtBQVosRUFBa0I7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQzZLLE9BQUcsR0FBQzdLLENBQUo7QUFBTTs7QUFBbEIsQ0FBbEIsRUFBc0MsQ0FBdEM7QUFBeUMsSUFBSW1ELFFBQUo7QUFBYXhELE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQ29ELFVBQVEsQ0FBQ25ELENBQUQsRUFBRztBQUFDbUQsWUFBUSxHQUFDbkQsQ0FBVDtBQUFXOztBQUF4QixDQUFyQixFQUErQyxDQUEvQztBQUFrRCxJQUFJRSxJQUFKO0FBQVNQLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLDRCQUFaLEVBQXlDO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNFLFFBQUksR0FBQ0YsQ0FBTDtBQUFPOztBQUFuQixDQUF6QyxFQUE4RCxDQUE5RDs7QUFNblEsTUFBTUMsS0FBTixDQUFZO0FBQ2pCOzs7Ozs7Ozs7QUFTQSxTQUFhWSxTQUFiLENBQXVCRixJQUF2QixFQUE2Qm1LLEVBQTdCO0FBQUEsb0NBQWlDO0FBQy9CLFlBQU1oRixJQUFJLEdBQUc2RSxFQUFFLENBQUNJLGdCQUFILENBQW9CcEssSUFBcEIsQ0FBYjtBQUNBLFlBQU00RixLQUFLLEdBQUcsSUFBSXBELFFBQUosQ0FBYTtBQUN6QjJCLGtCQUFVLEVBQUUsSUFEYTs7QUFFbkJ5QixhQUFOLENBQWF2QixLQUFiLEVBQW9CZ0csUUFBcEIsRUFBOEJDLFFBQTlCO0FBQUEsMENBQXdDO0FBQ3RDO0FBQ0Esa0JBQU10SixHQUFHLEdBQUd6QixJQUFJLENBQUM2QixJQUFMLENBQVVpRCxLQUFWLENBQVosQ0FGc0MsQ0FJdEM7O0FBQ0EsZ0JBQUk7QUFDRiw0QkFBTThGLEVBQUUsQ0FBQzNJLE1BQUgsQ0FBVVIsR0FBVixDQUFOO0FBQ0QsYUFGRCxDQUVFLE9BQU8yQyxHQUFQLEVBQVk7QUFDWjJHLHNCQUFRLENBQUMzRyxHQUFELENBQVI7QUFDRCxhQVRxQyxDQVd0Qzs7O0FBQ0EyRyxvQkFBUTtBQUNULFdBYkQ7QUFBQTs7QUFGeUIsT0FBYixDQUFkO0FBa0JBLGFBQU8sSUFBSWpILE9BQUosQ0FBWSxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDdEM0QixZQUFJLENBQ0RGLElBREgsQ0FDUWdGLEtBQUssQ0FBQ00sWUFBTixDQUFtQixNQUFuQixDQURSLEVBRUd0RixJQUZILENBRVFnRixLQUFLLENBQUNPLFlBQU4sQ0FBbUIsT0FBbkIsQ0FGUixFQUdHdkYsSUFISCxDQUdRaUYsR0FBRyxDQUFDTyxLQUFKLENBQVU7QUFBRUMsaUJBQU8sRUFBRTtBQUFYLFNBQVYsQ0FIUixFQUlHekYsSUFKSCxDQUlRVyxLQUpSLEVBS0dsQyxFQUxILENBS00sUUFMTixFQUtnQixNQUFNO0FBQ2xCSixpQkFBTztBQUNSLFNBUEgsRUFRR0ksRUFSSCxDQVFNLE9BUk4sRUFRZ0JDLEdBQUQsSUFBUztBQUNwQkosZ0JBQU0sQ0FBQ0ksR0FBRCxDQUFOO0FBQ0QsU0FWSDtBQVdELE9BWk0sQ0FBUDtBQWFELEtBakNEO0FBQUE7O0FBVmlCLEM7Ozs7Ozs7Ozs7O0FDTm5CM0UsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQzBMLGdCQUFjLEVBQUMsTUFBSUE7QUFBcEIsQ0FBZDtBQUFtRCxJQUFJdEksT0FBSjtBQUFZckQsTUFBTSxDQUFDSSxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQ2lELFNBQU8sQ0FBQ2hELENBQUQsRUFBRztBQUFDZ0QsV0FBTyxHQUFDaEQsQ0FBUjtBQUFVOztBQUF0QixDQUFyQyxFQUE2RCxDQUE3RDs7QUFFeEQsTUFBTXNMLGNBQU4sQ0FBcUI7QUFDMUJqSSxhQUFXLENBQUNHLEtBQUQsRUFBUStILE9BQVIsRUFBaUI7QUFDMUIsU0FBS3JCLEVBQUwsR0FBVWxILE9BQU8sQ0FBQ2IsTUFBUixDQUNSO0FBQ0VxQixXQURGO0FBRUUrSCxhQUZGO0FBR0VDLGVBQVMsRUFBRTNKLElBQUksQ0FBQ0MsR0FBTCxFQUhiO0FBSUUySixhQUFPLEVBQUU7QUFKWCxLQURRLENBQVY7QUFRRDs7QUFFREMsS0FBRyxDQUFDSCxPQUFELEVBQVU7QUFDWHZJLFdBQU8sQ0FBQzFCLE1BQVIsQ0FBZSxLQUFLNEksRUFBcEIsRUFBd0I7QUFDdEIxSSxVQUFJLEVBQUU7QUFDSitKLGVBREk7QUFFSkUsZUFBTyxFQUFFNUosSUFBSSxDQUFDQyxHQUFMO0FBRkw7QUFEZ0IsS0FBeEI7QUFNRDs7QUFuQnlCLEM7Ozs7Ozs7Ozs7O0FDRjVCbkMsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ08sU0FBTyxFQUFDLE1BQUl3TDtBQUFiLENBQWQ7QUFBdUMsSUFBSXRKLGlCQUFKO0FBQXNCMUMsTUFBTSxDQUFDSSxJQUFQLENBQVkseUJBQVosRUFBc0M7QUFBQ3NDLG1CQUFpQixDQUFDckMsQ0FBRCxFQUFHO0FBQUNxQyxxQkFBaUIsR0FBQ3JDLENBQWxCO0FBQW9COztBQUExQyxDQUF0QyxFQUFrRixDQUFsRjtBQUFxRixJQUFJQyxLQUFKO0FBQVVOLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0UsT0FBSyxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsU0FBSyxHQUFDRCxDQUFOO0FBQVE7O0FBQWxCLENBQTVCLEVBQWdELENBQWhEOztBQUc3SSxNQUFNMkwsU0FBTixDQUFnQjtBQUM3QixTQUFhQyxTQUFiO0FBQUEsb0NBQXlCO0FBQ3ZCLG9CQUFNRCxTQUFTLENBQUNFLFlBQVYsRUFBTjtBQUNELEtBRkQ7QUFBQTs7QUFJQSxTQUFhQSxZQUFiO0FBQUEsb0NBQTRCO0FBQzFCLFlBQU1DLEdBQUcsR0FBR3pKLGlCQUFpQixDQUFDRSxHQUFsQixDQUFzQndKLE1BQWxDO0FBQ0EsVUFBSTdKLEtBQUssR0FBRyxDQUFaO0FBRUEsb0JBQU0sSUFBSThCLE9BQUosQ0FDSEMsT0FBRCxJQUFhO0FBQ1g1Qix5QkFBaUIsQ0FBQ0UsR0FBbEIsQ0FBc0JLLE9BQXRCLENBQ1NvSixDQUFQLDZCQUFhO0FBQ1gsd0JBQU1MLFNBQVMsQ0FBQ00sZUFBVixDQUNKRCxDQUFDLENBQUN0SixTQURFLEVBRUgsR0FBRUwsaUJBQWlCLENBQUNDLE9BQVEsSUFBRzBKLENBQUMsQ0FBQ3ZKLE9BQVEsRUFGdEMsQ0FBTjtBQUlBUCxlQUFLLElBQUksQ0FBVDs7QUFDQSxjQUFJQSxLQUFLLEtBQUs0SixHQUFkLEVBQW1CO0FBQ2pCN0gsbUJBQU87QUFDUjtBQUNGLFNBVEQsQ0FERjtBQVlELE9BZEcsQ0FBTjtBQWdCRCxLQXBCRDtBQUFBOztBQXNCQSxTQUFhZ0ksZUFBYixDQUE2QkMsUUFBN0IsRUFBdUNDLE9BQXZDO0FBQUEsb0NBQWdEO0FBQzlDLG9CQUFNRCxRQUFRLENBQUN0TCxNQUFULEVBQU47QUFDQSxvQkFBTVgsS0FBSyxDQUFDWSxTQUFOLENBQWdCc0wsT0FBaEIsRUFBeUJELFFBQXpCLENBQU47QUFDRCxLQUhEO0FBQUE7O0FBM0I2QixDOzs7Ozs7Ozs7OztBQ0gvQnZNLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGlCQUFaLEU7Ozs7Ozs7Ozs7O0FDQUFKLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUN3TSxlQUFhLEVBQUMsTUFBSUE7QUFBbkIsQ0FBZDtBQUFpRCxJQUFJbkssTUFBSjtBQUFXdEMsTUFBTSxDQUFDSSxJQUFQLENBQVksK0JBQVosRUFBNEM7QUFBQ2tDLFFBQU0sQ0FBQ2pDLENBQUQsRUFBRztBQUFDaUMsVUFBTSxHQUFDakMsQ0FBUDtBQUFTOztBQUFwQixDQUE1QyxFQUFrRSxDQUFsRTs7QUFFckQsTUFBTW9NLGFBQU4sQ0FBb0I7QUFDekIsU0FBT0MsR0FBUCxHQUFhO0FBQ1gsVUFBTUMsTUFBTSxHQUFHckssTUFBTSxDQUFDb0QsT0FBUCxFQUFmO0FBQ0EsV0FBT2lILE1BQVA7QUFDRDs7QUFKd0IsQzs7Ozs7Ozs7Ozs7QUNGM0IsSUFBSXhNLE1BQUo7QUFBV0gsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSTJLLEVBQUo7QUFBT2hMLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFVBQVosRUFBdUI7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQzJLLE1BQUUsR0FBQzNLLENBQUg7QUFBSzs7QUFBakIsQ0FBdkIsRUFBMEMsQ0FBMUM7QUFHdkVGLE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ2I7Ozs7OztBQU1NLGVBQU4sQ0FBcUI2TCxHQUFyQixFQUEwQkMsUUFBMUIsRUFBb0NDLFVBQXBDO0FBQUEsb0NBQWdEO0FBQzlDLFlBQU1DLFFBQVEsR0FBSSxHQUFFSCxHQUFJLElBQUdDLFFBQVMsRUFBcEM7QUFDQSxvQkFBTTdCLEVBQUUsQ0FBQ2dDLE1BQUgsQ0FBVUosR0FBVixDQUFOLEVBRjhDLENBSTlDOztBQUNBLFlBQU12SCxLQUFLLEdBQUc0SCxNQUFNLENBQUNDLElBQVAsQ0FBWUosVUFBWixFQUF3QixRQUF4QixDQUFkO0FBRUEsWUFBTUssR0FBRyxpQkFBU25DLEVBQUUsQ0FBQ29DLFNBQUgsQ0FBYUwsUUFBYixFQUF1QjFILEtBQXZCLENBQVQsQ0FBVDtBQUNBLGFBQU84SCxHQUFQO0FBQ0QsS0FURDtBQUFBLEdBUGE7O0FBa0JQLGFBQU4sQ0FBbUJOLFFBQW5CO0FBQUEsb0NBQTZCO0FBQzNCLFVBQUlRLElBQUo7O0FBQ0EsVUFBSTtBQUNGQSxZQUFJLGlCQUFTckMsRUFBRSxDQUFDcUMsSUFBSCxDQUFRUixRQUFSLENBQVQsQ0FBSjtBQUNELE9BRkQsQ0FFRSxPQUFPUixDQUFQLEVBQVU7QUFDVixjQUFNLElBQUlsTSxNQUFNLENBQUNtTixLQUFYLENBQWlCakIsQ0FBakIsQ0FBTjtBQUNEOztBQUNELGFBQU9nQixJQUFQO0FBQ0QsS0FSRDtBQUFBOztBQWxCYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDSEEsSUFBSWxOLE1BQUo7QUFBV0gsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSTJMLFNBQUo7QUFBY2hNLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLDhCQUFaLEVBQTJDO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUMyTCxhQUFTLEdBQUMzTCxDQUFWO0FBQVk7O0FBQXhCLENBQTNDLEVBQXFFLENBQXJFO0FBQXdFLElBQUlrTixZQUFKLEVBQWlCQyxpQkFBakIsRUFBbUM5SyxpQkFBbkM7QUFBcUQxQyxNQUFNLENBQUNJLElBQVAsQ0FBWSxpQ0FBWixFQUE4QztBQUFDbU4sY0FBWSxDQUFDbE4sQ0FBRCxFQUFHO0FBQUNrTixnQkFBWSxHQUFDbE4sQ0FBYjtBQUFlLEdBQWhDOztBQUFpQ21OLG1CQUFpQixDQUFDbk4sQ0FBRCxFQUFHO0FBQUNtTixxQkFBaUIsR0FBQ25OLENBQWxCO0FBQW9CLEdBQTFFOztBQUEyRXFDLG1CQUFpQixDQUFDckMsQ0FBRCxFQUFHO0FBQUNxQyxxQkFBaUIsR0FBQ3JDLENBQWxCO0FBQW9COztBQUFwSCxDQUE5QyxFQUFvSyxDQUFwSztBQUkzTUYsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYixzQkFBcUI7QUFDbkJpTCxhQUFTLENBQUNDLFNBQVY7QUFFQSxXQUFPLElBQVA7QUFDRCxHQUxZOztBQU9iLG9CQUFtQjtBQUNqQixVQUFNb0IsSUFBSSxHQUFHLEVBQWI7QUFFQTNLLHFCQUFpQixDQUFDRSxHQUFsQixDQUFzQkssT0FBdEIsQ0FBK0JvSixDQUFELElBQU87QUFDbkMsWUFBTW9CLEdBQUcsR0FBRyxFQUFaO0FBRUFBLFNBQUcsQ0FBQ2xMLEtBQUosR0FBWThKLENBQUMsQ0FBQ3JKLGVBQUYsQ0FBa0JuQyxJQUFsQixHQUF5QjBCLEtBQXpCLEVBQVo7QUFFQThLLFVBQUksQ0FBQ2hCLENBQUMsQ0FBQ3hKLE1BQUgsQ0FBSixHQUFpQjRLLEdBQWpCO0FBQ0QsS0FORDtBQVFBLFdBQU9KLElBQVA7QUFDRDs7QUFuQlksQ0FBZixFOzs7Ozs7Ozs7OztBQ0pBLElBQUlsTixNQUFKO0FBQVdILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl1SixnQkFBSjtBQUFxQjVKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHVDQUFaLEVBQW9EO0FBQUN3SixrQkFBZ0IsQ0FBQ3ZKLENBQUQsRUFBRztBQUFDdUosb0JBQWdCLEdBQUN2SixDQUFqQjtBQUFtQjs7QUFBeEMsQ0FBcEQsRUFBOEYsQ0FBOUY7QUFBaUcsSUFBSW9NLGFBQUo7QUFBa0J6TSxNQUFNLENBQUNJLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNxTSxlQUFhLENBQUNwTSxDQUFELEVBQUc7QUFBQ29NLGlCQUFhLEdBQUNwTSxDQUFkO0FBQWdCOztBQUFsQyxDQUF2QixFQUEyRCxDQUEzRDtBQUE4RCxJQUFJc0wsY0FBSjtBQUFtQjNMLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLDJCQUFaLEVBQXdDO0FBQUN1TCxnQkFBYyxDQUFDdEwsQ0FBRCxFQUFHO0FBQUNzTCxrQkFBYyxHQUFDdEwsQ0FBZjtBQUFpQjs7QUFBcEMsQ0FBeEMsRUFBOEUsQ0FBOUU7QUFBaUYsSUFBSXlHLGdCQUFKO0FBQXFCOUcsTUFBTSxDQUFDSSxJQUFQLENBQVksdUNBQVosRUFBb0Q7QUFBQzBHLGtCQUFnQixDQUFDekcsQ0FBRCxFQUFHO0FBQUN5RyxvQkFBZ0IsR0FBQ3pHLENBQWpCO0FBQW1COztBQUF4QyxDQUFwRCxFQUE4RixDQUE5Rjs7QUFNL1gsTUFBTXFOLFFBQU4sQ0FBZTtBQUNiLFNBQU9oQixHQUFQLEdBQWE7QUFDWCxVQUFNaUIsUUFBUSxHQUFHLEVBQWpCO0FBRUEsVUFBTWhCLE1BQU0sR0FBR0YsYUFBYSxDQUFDQyxHQUFkLEVBQWY7QUFDQWlCLFlBQVEsQ0FBQ2hCLE1BQVQsR0FBa0JBLE1BQWxCO0FBRUEsVUFBTS9JLFNBQVMsR0FBSSxhQUFZK0ksTUFBTSxDQUFDaUIsVUFBUCxDQUFrQkMsSUFBSyxJQUFHbEIsTUFBTSxDQUFDaUIsVUFBUCxDQUFrQkUsSUFBSyxJQUFHbkIsTUFBTSxDQUFDaUIsVUFBUCxDQUFrQjdJLEVBQUcsRUFBeEc7QUFDQSxVQUFNcEIsU0FBUyxHQUFJLGFBQVlnSixNQUFNLENBQUNvQixNQUFQLENBQWNILFVBQWQsQ0FBeUJDLElBQUssSUFBR2xCLE1BQU0sQ0FBQ29CLE1BQVAsQ0FBY0gsVUFBZCxDQUF5QkUsSUFBSyxJQUFHbkIsTUFBTSxDQUFDb0IsTUFBUCxDQUFjSCxVQUFkLENBQXlCN0ksRUFBRyxFQUE3SDtBQUVBNEksWUFBUSxDQUFDSyxnQkFBVCxHQUE0QixJQUFJcEUsZ0JBQUosQ0FBcUJqRyxTQUFyQixFQUFnQyxVQUFoQyxFQUE0Q0MsU0FBNUMsRUFBdUQsT0FBdkQsQ0FBNUI7QUFDQStKLFlBQVEsQ0FBQ00sZ0JBQVQsR0FBNEIsSUFBSW5ILGdCQUFKLENBQXFCbkQsU0FBckIsRUFBZ0MsT0FBaEMsRUFBeUNDLFNBQXpDLEVBQW9ELE9BQXBELENBQTVCO0FBRUEsV0FBTytKLFFBQVA7QUFDRDs7QUFkWTs7QUFpQmZ4TixNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNQLHFDQUFOO0FBQUEsb0NBQTZDO0FBQzNDLFlBQU00TSxRQUFRLEdBQUdELFFBQVEsQ0FBQ2hCLEdBQVQsRUFBakI7QUFDQSxZQUFNd0IsTUFBTSxpQkFBU1AsUUFBUSxDQUFDSyxnQkFBVCxDQUEwQjdKLG9CQUExQixFQUFULENBQVo7QUFDQSxhQUFPK0osTUFBUDtBQUNELEtBSkQ7QUFBQSxHQURhOztBQU9iLGtDQUFpQztBQUMvQixVQUFNUCxRQUFRLEdBQUdELFFBQVEsQ0FBQ2hCLEdBQVQsRUFBakI7QUFDQSxVQUFNeUIsRUFBRSxHQUFHLElBQUl4QyxjQUFKLENBQW1CLHlCQUFuQixFQUE4QyxTQUE5QyxDQUFYO0FBRUF4TCxVQUFNLENBQUNpTyxLQUFQLENBQWEsK0JBQVc7QUFDdEIsWUFBTWpCLEdBQUcsaUJBQVNRLFFBQVEsQ0FBQ0ssZ0JBQVQsQ0FBMEI5SCxPQUExQixFQUFULENBQVQ7QUFDQWlJLFFBQUUsQ0FBQ3BDLEdBQUgsQ0FBUSxHQUFFb0IsR0FBSSxlQUFkO0FBQ0QsS0FIWSxDQUFiO0FBS0EsV0FBTyxrQ0FBUDtBQUNELEdBakJZOztBQW1CUCxxQ0FBTjtBQUFBLG9DQUE2QztBQUMzQyxZQUFNUSxRQUFRLEdBQUdELFFBQVEsQ0FBQ2hCLEdBQVQsRUFBakI7QUFDQSxZQUFNd0IsTUFBTSxpQkFBU1AsUUFBUSxDQUFDTSxnQkFBVCxDQUEwQjlKLG9CQUExQixFQUFULENBQVo7QUFDQSxhQUFPK0osTUFBUDtBQUNELEtBSkQ7QUFBQSxHQW5CYTs7QUF5QmIsa0NBQWlDO0FBQy9CLFVBQU1QLFFBQVEsR0FBR0QsUUFBUSxDQUFDaEIsR0FBVCxFQUFqQjtBQUNBLFVBQU15QixFQUFFLEdBQUcsSUFBSXhDLGNBQUosQ0FBbUIseUJBQW5CLEVBQThDLFNBQTlDLENBQVg7QUFFQXhMLFVBQU0sQ0FBQ2lPLEtBQVAsQ0FBYSwrQkFBVztBQUN0QixZQUFNakIsR0FBRyxpQkFBU1EsUUFBUSxDQUFDTSxnQkFBVCxDQUEwQi9ILE9BQTFCLEVBQVQsQ0FBVDtBQUNBaUksUUFBRSxDQUFDcEMsR0FBSCxDQUFRLEdBQUVvQixHQUFJLGVBQWQ7QUFDRCxLQUhZLENBQWI7QUFLQSxXQUFPLGtDQUFQO0FBQ0Q7O0FBbkNZLENBQWYsRTs7Ozs7Ozs7Ozs7QUN2QkEsSUFBSWhOLE1BQUo7QUFBV0gsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSWtELFdBQUo7QUFBZ0J2RCxNQUFNLENBQUNJLElBQVAsQ0FBWSxTQUFaLEVBQXNCO0FBQUNtRCxhQUFXLENBQUNsRCxDQUFELEVBQUc7QUFBQ2tELGVBQVcsR0FBQ2xELENBQVo7QUFBYzs7QUFBOUIsQ0FBdEIsRUFBc0QsQ0FBdEQ7QUFHaEZGLE1BQU0sQ0FBQ1ksT0FBUCxDQUFlO0FBQ1Asc0JBQU4sQ0FBNEJzTixlQUE1QjtBQUFBLG9DQUE2QztBQUMzQyxVQUFJQyxRQUFKOztBQUVBLFVBQUk7QUFDRkEsZ0JBQVEsaUJBQVMvSyxXQUFXLENBQUNVLE9BQVosQ0FDZCxhQUFZb0ssZUFBZSxDQUFDUixJQUFLLElBQUdRLGVBQWUsQ0FBQ1AsSUFBSyxFQUQzQyxFQUVmO0FBQUU5Six5QkFBZSxFQUFFO0FBQW5CLFNBRmUsQ0FBVCxDQUFSO0FBS0EsY0FBTWUsRUFBRSxHQUFHdUosUUFBUSxDQUFDdkosRUFBVCxDQUFZc0osZUFBZSxDQUFDdEosRUFBNUIsQ0FBWDtBQUVBLGNBQU13SixNQUFNLGlCQUFTeEosRUFBRSxDQUFDeUosZUFBSCxHQUFxQkMsT0FBckIsRUFBVCxDQUFaO0FBRUEsZUFBT0YsTUFBUDtBQUNELE9BWEQsQ0FXRSxPQUFPbEMsQ0FBUCxFQUFVO0FBQ1YsWUFBSUEsQ0FBQyxDQUFDcEYsSUFBTixFQUFZO0FBQ1YsZ0JBQU0sSUFBSTlHLE1BQU0sQ0FBQ21OLEtBQVgsQ0FBaUJqQixDQUFDLENBQUNwRixJQUFuQixFQUF5Qm9GLENBQUMsQ0FBQ1QsT0FBM0IsQ0FBTjtBQUNEOztBQUNELGNBQU1TLENBQU47QUFDRCxPQWhCRCxTQWdCVTtBQUNSLFlBQUlpQyxRQUFKLEVBQWNBLFFBQVEsQ0FBQ3pJLEtBQVQ7QUFDZjtBQUNGLEtBdEJEO0FBQUE7O0FBRGEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0hBLElBQUkxRixNQUFKO0FBQVdILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlxTyxLQUFKO0FBQVUxTyxNQUFNLENBQUNJLElBQVAsQ0FBWSxPQUFaLEVBQW9CO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNxTyxTQUFLLEdBQUNyTyxDQUFOO0FBQVE7O0FBQXBCLENBQXBCLEVBQTBDLENBQTFDO0FBRzFFRixNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNiLHVCQUFzQjROLFNBQXRCLEVBQWlDO0FBQy9CLFVBQU1DLEdBQUcsR0FBR0YsS0FBSyxDQUFDRyxnQkFBTixDQUF1QkYsU0FBdkIsQ0FBWjtBQUVBeE8sVUFBTSxDQUFDMk8sU0FBUCxDQUFrQkMsR0FBRCxJQUFTO0FBQ3hCSCxTQUFHLENBQUMzSyxPQUFKLENBQWFVLEdBQUQsSUFBUztBQUNuQm9LLFdBQUcsQ0FBQ3BLLEdBQUQsQ0FBSDtBQUNELE9BRkQ7QUFHRCxLQUpEO0FBTUEsVUFBTXdJLEdBQUcsR0FBR2hOLE1BQU0sQ0FBQzJPLFNBQVAsQ0FBa0JDLEdBQUQsSUFBUztBQUNwQ0gsU0FBRyxDQUFDSSxLQUFKLENBQVcsZ0VBQStETCxTQUFTLENBQUNNLFFBQVMsR0FBN0YsRUFBaUcsQ0FBQ3RLLEdBQUQsRUFBTXVLLE9BQU4sS0FBa0I7QUFDakhILFdBQUcsQ0FBQ3BLLEdBQUQsRUFBTXVLLE9BQU4sQ0FBSDtBQUNELE9BRkQ7QUFHRCxLQUpXLEdBQVo7QUFNQU4sT0FBRyxDQUFDN0MsR0FBSjtBQUVBLFVBQU1vRCxTQUFTLEdBQUdDLElBQUksQ0FBQ0MsU0FBTCxDQUFlbEMsR0FBZixDQUFsQjs7QUFDQSxRQUFJZ0MsU0FBUyxLQUFLLElBQWxCLEVBQXdCO0FBQ3RCLFlBQU0sSUFBSWhQLE1BQU0sQ0FBQ21OLEtBQVgsQ0FBaUIsbUJBQWpCLENBQU47QUFDRDs7QUFFRCxXQUFPOEIsSUFBSSxDQUFDQyxTQUFMLENBQWVsQyxHQUFmLENBQVA7QUFDRDs7QUF4QlksQ0FBZixFOzs7Ozs7Ozs7OztBQ0hBLElBQUloTixNQUFKO0FBQVdILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlzTCxjQUFKO0FBQW1CM0wsTUFBTSxDQUFDSSxJQUFQLENBQVksMkJBQVosRUFBd0M7QUFBQ3VMLGdCQUFjLENBQUN0TCxDQUFELEVBQUc7QUFBQ3NMLGtCQUFjLEdBQUN0TCxDQUFmO0FBQWlCOztBQUFwQyxDQUF4QyxFQUE4RSxDQUE5RTtBQUduRkYsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYixtQkFBa0I7QUFDaEIsVUFBTW9OLEVBQUUsR0FBRyxJQUFJeEMsY0FBSixDQUFtQixhQUFuQixFQUFrQyxRQUFsQyxDQUFYO0FBRUF4TCxVQUFNLENBQUNtUCxVQUFQLENBQ0UsTUFBTTtBQUNKbkIsUUFBRSxDQUFDcEMsR0FBSCxDQUFPLFFBQVA7QUFDRCxLQUhILEVBR0ssS0FITDtBQU1BLFdBQU8seUJBQVA7QUFDRDs7QUFYWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDSEEsSUFBSXpKLE1BQUo7QUFBV3RDLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLCtCQUFaLEVBQTRDO0FBQUNrQyxRQUFNLENBQUNqQyxDQUFELEVBQUc7QUFBQ2lDLFVBQU0sR0FBQ2pDLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSThDLEtBQUo7QUFBVW5ELE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLDhCQUFaLEVBQTJDO0FBQUMrQyxPQUFLLENBQUM5QyxDQUFELEVBQUc7QUFBQzhDLFNBQUssR0FBQzlDLENBQU47QUFBUTs7QUFBbEIsQ0FBM0MsRUFBK0QsQ0FBL0Q7QUFBa0VMLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGlDQUFaO0FBQStDSixNQUFNLENBQUNJLElBQVAsQ0FBWSxtQkFBWixFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBNZXRhIGZyb20gJy4uLy4uLy4uL3NoYXJlZC9tZXRlb3JNb25nby9tZXRhJztcblxuZXhwb3J0IGNvbnN0IHN0cnV0TmV3SXRlbXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignc3RydXROZXdJdGVtcycsIHsgaWRHZW5lcmF0aW9uOiAnTU9OR08nIH0pO1xuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICBNZXRlb3IucHVibGlzaCgnc3RydXROZXdJdGVtcycsICgpID0+IHN0cnV0TmV3SXRlbXMuZmluZCgpKTtcbn1cbk1ldGEuaW5qZWN0KHN0cnV0TmV3SXRlbXMpO1xuIiwiaW1wb3J0ICcuL21ldGhvZCc7XG5pbXBvcnQgJy4vY29sbGVjdGlvbic7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnLi4vLi4vLi4vZGF0YS9tb25nbyc7XG5pbXBvcnQgeyBzdHJ1dE5ld0l0ZW1zIH0gZnJvbSAnLi9jb2xsZWN0aW9uJztcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgLyoqXG4gICAgICpcbiAgICAgKlxuICAgICAqIEBwYXJhbSB7Kn0gZmlsZSDlj5bjgorovrzjgoBDU1bjg5XjgqHjgqTjg6vjga7ntbblr77jg5HjgrlcbiAgICAgKi9cbiAgICAnc3RydXQuaW1wb3J0TmV3JyAoZmlsZSkge1xuICAgICAgc3RydXROZXdJdGVtcy5yZW1vdmUoe30pO1xuICAgICAgTW9uZ28uaW1wb3J0Q3N2KGZpbGUsIHN0cnV0TmV3SXRlbXMucmF3Q29sbGVjdGlvbigpKTtcbiAgICB9LFxuICB9KTtcbn1cblxuIiwiaW1wb3J0ICcuL2ltcG9ydE5ldy9pbXBvcnQnO1xuIiwiaW1wb3J0ICcuL3N0cnV0L2ltcG9ydCc7XG4iLCJcbi8vIHJlZ3VsYXIga2V5IG5lZWRzIGluZGV4IHVzZWQgaW4gbW9uZ28gcXVlcnlcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1ldGEge1xuICAvKipcbiAgICpcbiAgICpcbiAgICogQHN0YXRpY1xuICAgKiBAcGFyYW0ge01vbmdvLkNvbGxlY3Rpb259IG1ldGVvck1vbmdvQ29sbGVjdGlvblxuICAgKiBAcmV0dXJuc1xuICAgKiBAbWVtYmVyb2YgTWV0YVxuICAgKi9cbiAgc3RhdGljIGluamVjdChtZXRlb3JNb25nb0NvbGxlY3Rpb24pIHtcbiAgICAvLyBhZGRpdGlvbmFsIGZ1bmN0aW9uIGZvciBjb2xsZWN0aW9uXG4gICAgbWV0ZW9yTW9uZ29Db2xsZWN0aW9uLnNlbGVjdGVkSXRlbXMgPSAoKSA9PiBtZXRlb3JNb25nb0NvbGxlY3Rpb24uZmluZCh7ICdtZXRhLnNlbGVjdCc6IHRydWUgfSk7XG5cbiAgICAvLyBtZXRob2RzIGZvciBlYWNoIGRvY3VtZW50c1xuICAgIG1ldGVvck1vbmdvQ29sbGVjdGlvbi5oZWxwZXJzKHtcbiAgICAgIHRvZ2dsZSgpIHtcbiAgICAgICAgdGhpcy5zZWxlY3QoIXRoaXMubWV0YS5zZWxlY3QpO1xuICAgICAgfSxcbiAgICAgIHNlbGVjdChib29sKSB7XG4gICAgICAgIG1ldGVvck1vbmdvQ29sbGVjdGlvbi51cGRhdGUoXG4gICAgICAgICAgeyBfaWQ6IHRoaXMuX2lkIH0sXG4gICAgICAgICAgeyAkc2V0OiB7ICdtZXRhLnNlbGVjdCc6IGJvb2wgfSB9LFxuICAgICAgICApO1xuICAgICAgICB0aGlzLm1ldGEuc2VsZWN0ID0gYm9vbDtcbiAgICAgIH0sXG4gICAgICBpc1NlbGVjdGVkKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5tZXRhLnNlbGVjdDtcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICAvLyBzZWN1cml0eVxuICAgIG1ldGVvck1vbmdvQ29sbGVjdGlvbi5hbGxvdyh7XG4gICAgICB1cGRhdGU6ICgpID0+IHRydWUsXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogQGRlcHJlY2F0ZWRcbiAgICogQHBhcmFtIHsqfSBkb2NcbiAgICovXG4gIHN0YXRpYyB1cGRhdGUoZG9jKSB7XG4gICAgLy8g44OJ44Kt44Ol44Oh44Oz44OI44OH44O844K/44KS5qSc5p+744GX44CBXG4gICAgLy8g5qyg6JC944GX44Gm44GE44KL5aC05ZCI44GrIG1ldGHjg5fjg63jg5Hjg4bjgqMg44KS5L2c5oiQ44GZ44KLXG4gICAgaWYgKHR5cGVvZiBkb2MubWV0YSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIGRvYy5tZXRhID0ge307XG4gICAgfVxuICAgIGRvYy5tZXRhLnVwZGF0ZVRpbWUgPSBEYXRlLm5vdygpO1xuICB9XG5cbiAgc3RhdGljIHdyYXAoZG9jKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIG1ldGE6IHtcbiAgICAgICAgdXBkYXRlVGltZTogRGF0ZS5ub3coKSxcbiAgICAgICAgc2VsZWN0OiBmYWxzZSxcbiAgICAgIH0sXG4gICAgICBkYXRhOiBkb2MsXG4gICAgfTtcbiAgfVxufVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBDb25maWcgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY29uZmlnJywgeyBpZEdlbmVyYXRpb246ICdNT05HTycgfSk7XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgaWYgKCFDb25maWcuZmluZCgpLmNvdW50KCkpIHtcbiAgICBDb25maWcuaW5zZXJ0KHt9KTtcbiAgfVxuICBNZXRlb3IucHVibGlzaCgnY29uZmlnJywgKCkgPT4gQ29uZmlnLmZpbmQoe30sIHsgbGltaXQ6IDEgfSkpO1xuXG4gIE1ldGVvci5tZXRob2RzKHtcbiAgICAnY29uZmlnLnVwZGF0ZScgKGRvYykge1xuICAgICAgQ29uZmlnLnVwZGF0ZSh7fSwgZG9jKTtcbiAgICB9LFxuICB9KTtcblxufVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgTWV0YSBmcm9tICcuLi9zaGFyZWQvbWV0ZW9yTW9uZ28vbWV0YSc7XG5cbmV4cG9ydCBjb25zdCBJbXBvcnRJclZBUklBQkxFUyA9IHtcbiAgd29ya2RpcjogJ2l0ZW1zL2ltcG9ydElyJyxcbiAgaXRlOiBbXG4gICAge1xuICAgICAgc3ltYm9sOiAnaXRlbVJvYm90SXRlbXMnLFxuICAgICAgY3N2ZmlsZTogJ2lyLWl0ZW0uY3N2JyxcbiAgICAgIG1vbmdvY29sbDogbnVsbCxcbiAgICAgIG1vbmdvQ29sbE1ldGVvcjogbnVsbCxcbiAgICB9LFxuICAgIHtcbiAgICAgIHN5bWJvbDogJ2l0ZW1Sb2JvdEl0ZW1PcHRpb24nLFxuICAgICAgY3N2ZmlsZTogJ2lyLWl0ZW1vcHRpb24uY3N2JyxcbiAgICAgIG1vbmdvY29sbDogbnVsbCxcbiAgICAgIG1vbmdvQ29sbE1ldGVvcjogbnVsbCxcbiAgICB9LFxuICAgIHtcbiAgICAgIHN5bWJvbDogJ2l0ZW1Sb2JvdFdvd21hJyxcbiAgICAgIGNzdmZpbGU6ICdpci1pdGVtc3ViX1dvd21hIS5jc3YnLFxuICAgICAgbW9uZ29jb2xsOiBudWxsLFxuICAgICAgbW9uZ29Db2xsTWV0ZW9yOiBudWxsLFxuICAgIH0sXG4gICAge1xuICAgICAgc3ltYm9sOiAnaXRlbVJvYm90WXNob3AnLFxuICAgICAgY3N2ZmlsZTogJ2lyLWl0ZW1zdWJfWWFob28uY3N2JyxcbiAgICAgIG1vbmdvY29sbDogbnVsbCxcbiAgICAgIG1vbmdvQ29sbE1ldGVvcjogbnVsbCxcbiAgICB9LFxuICAgIHtcbiAgICAgIHN5bWJvbDogJ2l0ZW1Sb2JvdFJha3V0ZW4nLFxuICAgICAgY3N2ZmlsZTogJ2lyLWl0ZW1zdWJf5qW95aSpLmNzdicsXG4gICAgICBtb25nb2NvbGw6IG51bGwsXG4gICAgICBtb25nb0NvbGxNZXRlb3I6IG51bGwsXG4gICAgfSxcbiAgICB7XG4gICAgICBzeW1ib2w6ICdpdGVtUm9ib3RTZWxlY3Rpb24nLFxuICAgICAgY3N2ZmlsZTogJ2lyLXNlbGVjdGlvbi5jc3YnLFxuICAgICAgbW9uZ29jb2xsOiBudWxsLFxuICAgICAgbW9uZ29Db2xsTWV0ZW9yOiBudWxsLFxuICAgIH0sXG4gICAge1xuICAgICAgc3ltYm9sOiAnaXRlbVJvYm90U2VsZWN0aW9uV293bWEnLFxuICAgICAgY3N2ZmlsZTogJ2lyLXNlbGVjdGlvbnN1Yl9Xb3dtYSEuY3N2JyxcbiAgICAgIG1vbmdvY29sbDogbnVsbCxcbiAgICAgIG1vbmdvQ29sbE1ldGVvcjogbnVsbCxcbiAgICB9LFxuICAgIHtcbiAgICAgIHN5bWJvbDogJ2l0ZW1Sb2JvdFNlbGVjdGlvbllzaG9wJyxcbiAgICAgIGNzdmZpbGU6ICdpci1zZWxlY3Rpb25zdWJfWWFob28uY3N2JyxcbiAgICAgIG1vbmdvY29sbDogbnVsbCxcbiAgICAgIG1vbmdvQ29sbE1ldGVvcjogbnVsbCxcbiAgICB9LFxuICAgIHtcbiAgICAgIHN5bWJvbDogJ2l0ZW1Sb2JvdFNlbGVjdGlvblJha3V0ZW4nLFxuICAgICAgY3N2ZmlsZTogJ2lyLXNlbGVjdGlvbnN1Yl/mpb3lpKkuY3N2JyxcbiAgICAgIG1vbmdvY29sbDogbnVsbCxcbiAgICAgIG1vbmdvQ29sbE1ldGVvcjogbnVsbCxcbiAgICB9LFxuICBdLFxufTtcblxuXG5JbXBvcnRJclZBUklBQkxFUy5pdGUuZm9yRWFjaCgoaXRlKSA9PiB7XG4gIGl0ZS5tb25nb0NvbGxNZXRlb3IgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihpdGUuc3ltYm9sLCB7IGlkR2VuZXJhdGlvbjogJ01PTkdPJyB9KTtcbiAgaXRlLm1vbmdvY29sbCA9IE1ldGVvci5pc1NlcnZlciA/IGl0ZS5tb25nb0NvbGxNZXRlb3IucmF3Q29sbGVjdGlvbigpIDogbnVsbDtcblxuICBNZXRhLmluamVjdChpdGUubW9uZ29Db2xsTWV0ZW9yKTtcblxuICBpdGUubW9uZ29Db2xsTWV0ZW9yLmFsbG93KHtcbiAgICBpbnNlcnQ6ICgpID0+IHRydWUsXG4gICAgcmVtb3ZlOiAoKSA9PiB0cnVlLFxuICB9KTtcblxuICBpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgTWV0ZW9yLnB1Ymxpc2goXG4gICAgICBpdGUuc3ltYm9sLFxuICAgICAgKCkgPT4gaXRlLm1vbmdvQ29sbE1ldGVvci5maW5kKCksXG4gICAgKTtcbiAgfVxufSk7XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgLy8gTWV0ZW9yLnB1Ymxpc2goXG4gIC8vICAgJ0ltcG9ydElySXRlbScsXG4gIC8vICAgKCkgPT4gSW1wb3J0SXJJdGVtLmZpbmQoKSxcbiAgLy8gKTtcblxuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgLyoqXG4gICAgICpcbiAgICAgKlxuICAgICAqIEBwYXJhbSB7U3RyaW5nfSBzdWJzY3JpYmVOYW1lXG4gICAgICovXG4gICAgJ2l0ZW1Sb2JvdC5yZW1vdmVDb2xsZWN0aW9uJyAoc3Vic2NyaWJlTmFtZSkge1xuICAgICAgSW1wb3J0SXJWQVJJQUJMRVMuaXRlLmZvckVhY2goKGl0ZSkgPT4ge1xuICAgICAgICBpZiAoaXRlLnN5bWJvbCA9PT0gc3Vic2NyaWJlTmFtZSkge1xuICAgICAgICAgIGl0ZS5tb25nb0NvbGxNZXRlb3IucmVtb3ZlKHt9KTtcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG4gIH0pXG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBNZXRhIGZyb20gJy4uL3NoYXJlZC9tZXRlb3JNb25nby9tZXRhJztcblxuZXhwb3J0IGNvbnN0IEl0ZW1zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2l0ZW1zJywgeyBpZEdlbmVyYXRpb246ICdNT05HTycgfSk7XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgTWV0ZW9yLnB1Ymxpc2goJ2l0ZW1zJywgKCkgPT4gSXRlbXMuZmluZCh7fSkpO1xuXG4gIEl0ZW1zLmFsbG93KHtcbiAgICByZW1vdmU6ICgpID0+IHRydWUsXG4gIH0pO1xuXG4gIEl0ZW1zLmRlbnkoe1xuICAgIGluc2VydDogKCkgPT4gdHJ1ZSxcbiAgICB1cGRhdGU6ICgpID0+IHRydWUsXG4gIH0pO1xuXG4gIE1ldGVvci5tZXRob2RzKHtcbiAgICAnaXRlbXMuaW5zZXJ0JyAoZG9jKSB7XG4gICAgICBNZXRhLnVwZGF0ZShkb2MpO1xuICAgICAgcmV0dXJuIEl0ZW1zLmluc2VydChkb2MpO1xuICAgIH0sXG5cbiAgICAnaXRlbXMudXBkYXRlJyAoZG9jKSB7XG4gICAgICBNZXRhLnVwZGF0ZShkb2MpO1xuICAgICAgcmV0dXJuIEl0ZW1zLnVwZGF0ZShkb2MuX2lkLCBkb2MpO1xuICAgIH0sXG4gIH0pO1xufVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBSZXF1ZXN0ID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3JlcXVlc3QnLCB7XG4gIGlkR2VuZXJhdGlvbjogJ01PTkdPJyxcbn0pO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gIE1ldGVvci5wdWJsaXNoKCdyZXF1ZXN0JywgKCkgPT4gUmVxdWVzdC5maW5kKCkpO1xufVxuIiwiaW1wb3J0IHsgTW9uZ29DbGllbnQgfSBmcm9tICdtb25nb2RiJztcblxuaW1wb3J0IHtcbiAgV3JpdGFibGUsIFRyYW5zZm9ybSxcbn0gZnJvbSAnc3RyZWFtJztcblxuZXhwb3J0IGNsYXNzIE1vbmdvT2xkTmV3IHtcbiAgY29uc3RydWN0b3IobW9uZ291T2xkLCBtb25nb3VOZXcpIHtcbiAgICB0aGlzLnRpdGxlID0gJ21vbmdvSXRlbXMgb2xkIHRvIG5ldyc7XG4gICAgdGhpcy5tb25nb3VPbGQgPSBtb25nb3VPbGQ7XG4gICAgdGhpcy5tb25nb3VOZXcgPSBtb25nb3VOZXc7XG4gIH1cblxuICBhc3luYyBnZXRPbGREYkNvbm5lY3QoKSB7XG4gICAgY29uc3QgY2xpZW50ID0gYXdhaXQgbmV3IE1vbmdvQ2xpZW50KHRoaXMubW9uZ291T2xkLCB7IHVzZU5ld1VybFBhcnNlcjogdHJ1ZSB9KS5jb25uZWN0KCk7XG4gICAgcmV0dXJuIGNsaWVudDtcbiAgfVxuXG4gIGFzeW5jIGdldE5ld0RiQ29ubmVjdCgpIHtcbiAgICBjb25zdCBjbGllbnQgPSBhd2FpdCBuZXcgTW9uZ29DbGllbnQodGhpcy5tb25nb3VOZXcsIHsgdXNlTmV3VXJsUGFyc2VyOiB0cnVlIH0pLmNvbm5lY3QoKTtcbiAgICByZXR1cm4gY2xpZW50O1xuICB9XG5cbiAgYXN5bmMgY291bnRJbXBvcnRDYW5kaWRhdGUoKSB7XG4gICAgY29uc3QgcHJvbWlzZSA9IG5ldyBQcm9taXNlKGFzeW5jIChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGxldCBjb3VudCA9IDA7XG5cbiAgICAgIGNvbnN0IHJlYWRDYW5kaWRhdGUgPSBhd2FpdCB0aGlzLnJlYWRhYmxlSW1wb3J0Q2FuZGlkYXRlKCk7XG4gICAgICByZWFkQ2FuZGlkYXRlXG4gICAgICAgIC5vbignZGF0YScsICgpID0+IHtcbiAgICAgICAgICBjb3VudCArPSAxO1xuICAgICAgICB9KVxuICAgICAgICAub24oJ2VuZCcsICgpID0+IHtcbiAgICAgICAgICByZXNvbHZlKGNvdW50KTtcbiAgICAgICAgfSlcbiAgICAgICAgLm9uKCdlcnJvcicsIChlcnIpID0+IHtcbiAgICAgICAgICByZWplY3QoZXJyKTtcbiAgICAgICAgfSk7XG5cbiAgICAgIHJlYWRDYW5kaWRhdGUucmVzdW1lKCk7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gcHJvbWlzZTtcbiAgfVxuXG4gIGFzeW5jIHJlYWRhYmxlSW1wb3J0Q2FuZGlkYXRlKCkge1xuICAgIGNvbnN0IG1vbmdvY09sZCA9IGF3YWl0IHRoaXMuZ2V0T2xkRGJDb25uZWN0KCk7XG4gICAgY29uc3Qgb2xkRGIgPSBtb25nb2NPbGQuZGIoKTtcbiAgICBcbiAgICBjb25zdCBtb25nb2NOZXcgPSBhd2FpdCB0aGlzLmdldE5ld0RiQ29ubmVjdCgpO1xuICAgIGNvbnN0IG5ld0RiID0gbW9uZ29jTmV3LmRiKCk7XG5cbiAgICBjb25zdCB0Zk5vdEV4aXN0ID0gbmV3IFRyYW5zZm9ybSh7XG4gICAgICBvYmplY3RNb2RlOiB0cnVlLFxuICAgICAgdHJhbnNmb3JtOiBhc3luYyAoY2h1bmssIGVuYywgY2IpID0+IHtcbiAgICAgICAgLy8g6Lui6YCB5YWI44Gu44OH44O844K/44OZ44O844K544Gr5ZCM44GYSUTjgYzlrZjlnKjjgZnjgovjgYvnorrjgYvjgoHjgotcbiAgICAgICAgbGV0IGRhdGE7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgZGF0YSA9IGF3YWl0IG5ld0RiLmNvbGxlY3Rpb24odGhpcy5jb2xOZXcpXG4gICAgICAgICAgICAuZmluZE9uZShjaHVuay5faWQsIHsgcHJvamVjdGlvbjogeyBfaWQ6IDEgfSB9KTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgY2IoZXJyKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghZGF0YSkge1xuICAgICAgICAgIC8vIOi7oumAgeWFiOOBruODh+ODvOOCv+ODmeODvOOCueOBq+WQjOOBmElE44GM5a2Y5Zyo44GX44Gq44GR44KM44Gw44K544OI44Oq44O844Og44Gr5rih44GZXG4gICAgICAgICAgY2IobnVsbCwgY2h1bmspO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNiKCk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBmaW5hbDogYXN5bmMgKGNiKSA9PiB7XG4gICAgICAgIC8vIOaXp+ODh+ODvOOCv+ODmeODvOOCueOBqOOBruaOpee2muOCkumWieOBmOOCi1xuICAgICAgICBhd2FpdCBtb25nb2NPbGQuY2xvc2UoKTtcbiAgICAgICAgYXdhaXQgbW9uZ29jTmV3LmNsb3NlKCk7XG4gICAgICAgIGNiKCk7XG4gICAgICB9LFxuICAgIH0pO1xuXG4gICAgY29uc3QgcmVhZGFibGUgPSBvbGREYi5jb2xsZWN0aW9uKHRoaXMuY29sT2xkKVxuICAgICAgLmZpbmQoKVxuICAgICAgLnByb2plY3QoKVxuICAgICAgLnBpcGUodGZOb3RFeGlzdCk7XG5cbiAgICByZXR1cm4gcmVhZGFibGU7XG4gIH1cblxuICBhc3luYyBtaWdyYXRlKHJlYWQpIHtcbiAgICAvLyBjb25zdCByZXZDb25kaXRpb24gPSBhd2FpdCBzdXBlci5taWdyYXRlKGNvbmRpdGlvbik7XG4gICAgbGV0IHJldlJlYWQgPSByZWFkO1xuICAgIGlmICghcmV2UmVhZCkgeyByZXZSZWFkID0gYXdhaXQgdGhpcy5yZWFkYWJsZUltcG9ydENhbmRpZGF0ZSgpOyB9XG5cbiAgICBjb25zdCB0ZkRhdGEgPSBuZXcgVHJhbnNmb3JtKHtcbiAgICAgIHJlYWRhYmxlT2JqZWN0TW9kZTogdHJ1ZSxcbiAgICAgIHdyaXRhYmxlT2JqZWN0TW9kZTogdHJ1ZSxcbiAgICAgIHRyYW5zZm9ybTogYXN5bmMgKGNodW5rLCBlbmMsIGNiKSA9PiB7XG4gICAgICAgIC8vIOODh+ODvOOCv+OBruWkieaPm1xuICAgICAgICBjb25zdCBkYXRhID0gdGhpcy5jb252ZXJ0KGNodW5rKTtcblxuICAgICAgICBjYihudWxsLCBkYXRhKTtcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICAvLyDnp7vooYzlhYggbW9uZ29kYiDjgajmjqXntppcbiAgICBjb25zdCBtb25nb2NOZXcgPSBhd2FpdCB0aGlzLmdldE5ld0RiQ29ubmVjdCgpO1xuICAgIGNvbnN0IG5ld0RiID0gbW9uZ29jTmV3LmRiKCk7XG5cbiAgICBjb25zdCB0ZldyaXRlTW9uZ29OZXcgPSBuZXcgVHJhbnNmb3JtKHtcbiAgICAgIHJlYWRhYmxlT2JqZWN0TW9kZTogdHJ1ZSxcbiAgICAgIHdyaXRhYmxlT2JqZWN0TW9kZTogdHJ1ZSxcbiAgICAgIHRyYW5zZm9ybTogYXN5bmMgKGNodW5rLCBlbmMsIGNiKSA9PiB7XG4gICAgICAgIGxldCBjbXIgPSBudWxsO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNtciA9IGF3YWl0IG5ld0RiLmNvbGxlY3Rpb24odGhpcy5jb2xOZXcpLmluc2VydE9uZShjaHVuayk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIGNiKGVycik7XG4gICAgICAgIH1cbiAgICAgICAgY2IobnVsbCwgY21yKTtcbiAgICAgIH0sXG4gICAgICBmaW5hbDogYXN5bmMgKGNiKSA9PiB7XG4gICAgICAgIC8vIOODh+ODvOOCv+ODmeODvOOCueOBqOOBruaOpee2muOCkumWieOBmOOCi1xuICAgICAgICBhd2FpdCBtb25nb2NOZXcuY2xvc2UoKTtcbiAgICAgICAgY2IoKTtcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICBsZXQgY291bnQgPSAwO1xuICAgIGNvbnN0IHdyaXRlID0gbmV3IFdyaXRhYmxlKHtcbiAgICAgIG9iamVjdE1vZGU6IHRydWUsXG4gICAgICB3cml0ZTogKGNodW5rLCBlbmMsIGNiKSA9PiB7XG4gICAgICAgIGNvdW50ICs9IGNodW5rLmluc2VydGVkQ291bnQ7XG4gICAgICAgIGNiKCk7XG4gICAgICB9LFxuICAgIH0pO1xuXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHJldlJlYWRcbiAgICAgICAgLnBpcGUodGZEYXRhKVxuICAgICAgICAucGlwZSh0ZldyaXRlTW9uZ29OZXcpXG4gICAgICAgIC5waXBlKHdyaXRlKVxuICAgICAgICAub24oJ2ZpbmlzaCcsICgpID0+IHtcbiAgICAgICAgICByZXNvbHZlKGNvdW50KTtcbiAgICAgICAgfSlcbiAgICAgICAgLm9uKCdlcnJvcicsIChlcnIpID0+IHtcbiAgICAgICAgICByZWplY3QoZXJyKTtcbiAgICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbn1cbiIsImltcG9ydCB1bmlxaWQgZnJvbSAndW5pcWlkJztcbmltcG9ydCB7IE1vbmdvT2xkTmV3IH0gZnJvbSAnLi9tb25nb09sZE5ldyc7XG5pbXBvcnQgTWV0YSBmcm9tICcuLi9zaGFyZWQvbWV0ZW9yTW9uZ28vbWV0YSc7XG5cbmV4cG9ydCBjbGFzcyBNb25nb09sZE5ld0V4aGliIGV4dGVuZHMgTW9uZ29PbGROZXcge1xuICBjb25zdHJ1Y3Rvcihtb25nb3VPbGQsIGNvbE9sZCwgbW9uZ291TmV3LCBjb2xOZXcpIHtcbiAgICBzdXBlcihtb25nb3VPbGQsIG1vbmdvdU5ldyk7XG4gICAgdGhpcy50aXRsZSA9ICdtaWdyYXRpb24gb2YgbW9uZ28gZXhoaWJpdGlvbiBkYXRhIGZyb20gb2xkIHRvIG5ldyc7XG5cbiAgICB0aGlzLmNvbE9sZCA9IGNvbE9sZDtcbiAgICB0aGlzLmNvbE5ldyA9IGNvbE5ldztcblxuICAgIHRoaXMuY29udmVydCA9IChjaHVuaykgPT4ge1xuICAgICAgLy8g44OJ44Kt44Ol44Oh44Oz44OI44Gu5qeL5oiQXG5cbiAgICAgIC8vIOWfuua6luOBqOOBquOCi+WVhuWTgeaDheWgsVxuICAgICAgY29uc3QgYmFzZSA9IHtcbiAgICAgICAgdGl0bGU6IGNodW5rLm5hbWUsXG4gICAgICAgIGl0ZW06IGNodW5rLnByb2R1Y3QsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBjaHVuay5kZXNjcmlwdGlvbixcbiAgICAgICAgaW1hZ2VzOiBjaHVuay5pbWFnZXMsXG4gICAgICAgIGRlbGl2ZXJ5OiBjaHVuay5kZWxpdmVyeSxcbiAgICAgICAgamFuOiBjaHVuay5qYW5fY29kZSxcbiAgICAgICAgY2xhc3MxTmFtZTogY2h1bmsuY2xhc3MxX25hbWUsXG4gICAgICAgIGNsYXNzMVZhbHVlOiBjaHVuay5jbGFzczFfdmFsdWUsXG4gICAgICAgIGNsYXNzMk5hbWU6IGNodW5rLmNsYXNzMl9uYW1lLFxuICAgICAgICBjbGFzczJWYWx1ZTogY2h1bmsuY2xhc3MyX3ZhbHVlLFxuICAgICAgICByZXRhaWxQcmljZTogY2h1bmsucmV0YWlsX3ByaWNlLFxuICAgICAgICB0YWc6IGNodW5rLnRhZyxcbiAgICAgICAgY2xvc2U6IGNodW5rLmNsb3NlLFxuICAgICAgfTtcblxuICAgICAgLy8g5qW95aSp5ZWG5ZOB5oOF5aCxXG4gICAgICBjb25zdCByYWt1dGVuID0gY2h1bmsubWFsbC5yYWt1dGVuXG4gICAgICAgID8ge1xuICAgICAgICAgIGl0ZW1Vcmw6IGNodW5rLm1hbGwucmFrdXRlbi5pdGVtVXJsLFxuICAgICAgICAgIEhDaG9pY2VOYW1lOiBjaHVuay5tYWxsLnJha3V0ZW4uSENob2ljZU5hbWUsXG4gICAgICAgICAgVkNob2ljZU5hbWU6IGNodW5rLm1hbGwucmFrdXRlbi5WQ2hvaWNlTmFtZSxcbiAgICAgICAgfVxuICAgICAgICA6IG51bGw7XG5cbiAgICAgIC8vIOODpOODleODvOOCt+ODp+ODg+ODlOODs+OCsOWVhuWTgeaDheWgsVxuICAgICAgY29uc3QgeXNob3AgPSBjaHVuay5tYWxsLnlzaG9wXG4gICAgICAgID8ge1xuICAgICAgICAgIGl0ZW1Db2RlOiBjaHVuay5tYWxsLnlzaG9wLml0ZW1fY29kZSxcbiAgICAgICAgICBzdWJDb2RlOiBjaHVuay5tYWxsLnlzaG9wLnN1Yl9jb2RlLFxuICAgICAgICB9XG4gICAgICAgIDogbnVsbDtcblxuICAgICAgLy8g44Ok44OV44Kq44Kv5ZWG5ZOB5oOF5aCxXG4gICAgICBjb25zdCB5YXVjdCA9IGNodW5rLm1hbGwueWF1Y3RcbiAgICAgICAgPyB7XG4gICAgICAgICAgdWlkOiB1bmlxaWQoKSxcbiAgICAgICAgICBjYXRlZ29yeTogY2h1bmsubWFsbC55YXVjdC5jYXRlZ29yeSxcbiAgICAgICAgICBtaW5RdWFudGl0eTogY2h1bmsubWFsbC55YXVjdC5taW5RdWFudGl0eSxcbiAgICAgICAgfVxuICAgICAgICA6IG51bGw7XG5cbiAgICAgIC8vIHNoYXJha3Utc2hvcCDllYblk4Hmg4XloLFcbiAgICAgIGNvbnN0IHNoYXJha3VTaG9wID0gY2h1bmsubWFsbC5zaGFyYWt1U2hvcFxuICAgICAgICA/IHtcbiAgICAgICAgICBwcm9kdWN0X2lkOiBjaHVuay5tYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfaWQsXG4gICAgICAgICAgcHJvZHVjdF9jbGFzc19pZDogY2h1bmsubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkLFxuICAgICAgICAgIHByb2R1Y3Rfc3RvY2tfaWQ6IGNodW5rLm1hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9zdG9ja19pZCxcbiAgICAgICAgICBwcmljZTogY2h1bmsubWFsbC5zaGFyYWt1U2hvcC5wcmljZSxcbiAgICAgICAgfVxuICAgICAgICA6IG51bGw7XG5cbiAgICAgIC8vIFdvd21hIOalveWkqeWVhuWTgeaDheWgsVxuICAgICAgY29uc3Qgd293bWEgPSBjaHVuay5tYWxsLndvd21hXG4gICAgICAgID8ge1xuICAgICAgICAgIEhDaG9pY2VOYW1lOiBjaHVuay5tYWxsLndvd21hLkhDaG9pY2VOYW1lLFxuICAgICAgICAgIFZDaG9pY2VOYW1lOiBjaHVuay5tYWxsLndvd21hLlZDaG9pY2VOYW1lLFxuICAgICAgICAgIGl0ZW1Db2RlOiBjaHVuay5tYWxsLndvd21hLml0ZW1Db2RlLFxuICAgICAgICAgIGl0ZW1NYW5hZ2VtZW50SWQ6IGNodW5rLm1hbGwud293bWEuaXRlbU1hbmFnZW1lbnRJZCxcbiAgICAgICAgfVxuICAgICAgICA6IG51bGw7XG5cbiAgICAgIGNvbnN0IGRhdGEgPSB7XG4gICAgICAgIGJhc2UsXG4gICAgICAgIHJha3V0ZW4sXG4gICAgICAgIHlzaG9wLFxuICAgICAgICB5YXVjdCxcbiAgICAgICAgc2hhcmFrdVNob3AsXG4gICAgICAgIHdvd21hLFxuICAgICAgfTtcblxuICAgICAgT2JqZWN0LmtleXMoZGF0YSkuZm9yRWFjaChcbiAgICAgICAgKGtleSkgPT4ge1xuICAgICAgICAgIGRhdGFba2V5XSA9IE1ldGEud3JhcChkYXRhW2tleV0pO1xuICAgICAgICB9LFxuICAgICAgKTtcbiAgICAgIC8vIGNvbnN0IGRhdGEgPSB7XG4gICAgICAvLyAgIGJhc2U6IE1ldGEud3JhcChiYXNlKSxcbiAgICAgIC8vICAgcmFrdXRlbjogTWV0YS53cmFwKHJha3V0ZW4pLFxuICAgICAgLy8gICB5c2hvcDogTWV0YS53cmFwKHlzaG9wKSxcbiAgICAgIC8vICAgeWF1Y3Q6IE1ldGEud3JhcCh5YXVjdCksXG4gICAgICAvLyAgIHNoYXJha3VTaG9wOiBNZXRhLndyYXAoc2hhcmFrdVNob3ApLFxuICAgICAgLy8gICB3b3dtYTogTWV0YS53cmFwKHdvd21hKSxcbiAgICAgIC8vIH07XG5cbiAgICAgIGNvbnN0IGRvYyA9IE1ldGEud3JhcChkYXRhKTtcbiAgICAgIGRvYy5faWQgPSBjaHVuay5faWQ7XG5cbiAgICAgIHJldHVybiBkb2M7XG4gICAgfTtcbiAgfVxufVxuIiwiaW1wb3J0IHsgTW9uZ29PbGROZXcgfSBmcm9tICcuL21vbmdvT2xkTmV3JztcblxuZXhwb3J0IGNsYXNzIE1vbmdvT2xkTmV3SXRlbXMgZXh0ZW5kcyBNb25nb09sZE5ldyB7XG4gIGNvbnN0cnVjdG9yKG1vbmdvdU9sZCwgY29sT2xkLCBtb25nb3VOZXcsIGNvbE5ldykge1xuICAgIHN1cGVyKG1vbmdvdU9sZCwgbW9uZ291TmV3KTtcbiAgICB0aGlzLnRpdGxlID0gJ21pZ3JhdGlvbiBvZiBtb25nbyBpdGVtcyBmcm9tIG9sZCB0byBuZXcnO1xuXG4gICAgdGhpcy5jb2xPbGQgPSBjb2xPbGQ7XG4gICAgdGhpcy5jb2xOZXcgPSBjb2xOZXc7XG5cbiAgICB0aGlzLmNvbnZlcnQgPSAoY2h1bmspID0+IHtcbiAgICAgIC8vIOWcqOW6q+OBruWkieaPm1xuICAgICAgY29uc3Qgc3RvY2sgPSBjaHVuay5zdG9jay5tYXAoKGVsZW1lbnQpID0+IHtcbiAgICAgICAgY29uc3QgcmVzRWxlbWVudCA9IHt9O1xuICAgICAgICByZXNFbGVtZW50LnF1YW50aXR5ID0gZWxlbWVudC5xdWFudGl0eTtcbiAgICAgICAgc3dpdGNoIChlbGVtZW50LmRlbGl2ZXJ5X2RhdGVfaWQpIHtcbiAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICByZXNFbGVtZW50LmxlYWR0aW1lID0gMztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgMjpcbiAgICAgICAgICAgIHJlc0VsZW1lbnQubGVhZHRpbWUgPSAzO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgcmVzRWxlbWVudC5sZWFkdGltZSA9IDQ7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICBjYXNlIDQ6XG4gICAgICAgICAgICByZXNFbGVtZW50LmxlYWR0aW1lID0gNTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgNTpcbiAgICAgICAgICAgIHJlc0VsZW1lbnQubGVhZHRpbWUgPSAxNDtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgNjpcbiAgICAgICAgICAgIHJlc0VsZW1lbnQubGVhZHRpbWUgPSAyMTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgNzpcbiAgICAgICAgICAgIHJlc0VsZW1lbnQubGVhZHRpbWUgPSAtMTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgODpcbiAgICAgICAgICAgIHJlc0VsZW1lbnQubGVhZHRpbWUgPSAtMTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgOTpcbiAgICAgICAgICAgIHJlc0VsZW1lbnQubGVhZHRpbWUgPSAtMTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgMTA6XG4gICAgICAgICAgICByZXNFbGVtZW50LmxlYWR0aW1lID0gMDtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgMTE6XG4gICAgICAgICAgICByZXNFbGVtZW50LmxlYWR0aW1lID0gMTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGRlZmF1bHQ6IHJlc0VsZW1lbnQubGVhZHRpbWUgPSAtMTtcbiAgICAgICAgfVxuICAgICAgICBzd2l0Y2ggKGVsZW1lbnQud2FyZWhvdXNlX2lkKSB7XG4gICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgcmVzRWxlbWVudC53YXJlaG91c2UgPSAn44K444Kn44Kk44Op44Kk44Oz44K444Oj44OR44OzJztcbiAgICAgICAgICAgIHJlc0VsZW1lbnQubGVhZHRpbWUgPSAxO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgcmVzRWxlbWVudC53YXJlaG91c2UgPSAn6Z+T5Zu9JztcbiAgICAgICAgICAgIHJlc0VsZW1lbnQubGVhZHRpbWUgPSAyMTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgMzpcbiAgICAgICAgICAgIHJlc0VsZW1lbnQud2FyZWhvdXNlID0gJ+OCs+ODn+ODjSc7XG4gICAgICAgICAgICByZXNFbGVtZW50LmxlYWR0aW1lID0gMztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgNDpcbiAgICAgICAgICAgIHJlc0VsZW1lbnQud2FyZWhvdXNlID0gJ+OCueODiOODqeODg+ODiCc7XG4gICAgICAgICAgICByZXNFbGVtZW50LmxlYWR0aW1lID0gMztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgNTpcbiAgICAgICAgICAgIHJlc0VsZW1lbnQud2FyZWhvdXNlID0gJ+OBiuWPluWvhOOBmyc7XG4gICAgICAgICAgICByZXNFbGVtZW50LmxlYWR0aW1lID0gLTE7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgcmVzRWxlbWVudC53YXJlaG91c2UgPSAnJztcbiAgICAgICAgICAgIHJlc0VsZW1lbnQubGVhZHRpbWUgPSAtMTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzRWxlbWVudDtcbiAgICAgIH0pO1xuICAgICAgLy8g6YWN6YCB5pa55rOV44Gu5aSJ5o+bXG4gICAgICBsZXQgZGVsaXZlcnk7XG4gICAgICBzd2l0Y2ggKGNodW5rLnBvc3RhZ2UuaWQpIHtcbiAgICAgICAgY2FzZSAxOlxuICAgICAgICAgIGRlbGl2ZXJ5ID0gWyflroXphY3kvr8nXTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAyOlxuICAgICAgICAgIGRlbGl2ZXJ5ID0gWyflroXphY3kvr8nLCAn44KG44GG44OR44Kx44OD44OIJ107XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6IGRlbGl2ZXJ5ID0gW107XG4gICAgICB9XG4gICAgICAvLyDjg4njgq3jg6Xjg6Hjg7Pjg4jjga7mp4vmiJBcbiAgICAgIGNvbnN0IGRvYyA9IHtcbiAgICAgICAgX2lkOiBjaHVuay5faWQsXG4gICAgICAgIG1ldGE6IHtcbiAgICAgICAgICB1cGRhdGVUaW1lOiBEYXRlLm5vdygpLFxuICAgICAgICB9LFxuICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgbmFtZTogY2h1bmsubmFtZSxcbiAgICAgICAgICBqYW46IE1hdGguZmxvb3IoY2h1bmsuamFuX2NvZGUpLFxuICAgICAgICAgIGpsaW5lOiBjaHVuay5qbGluZV9jb2RlLFxuICAgICAgICAgIHJldGFpbFByaWNlOiBjaHVuay5yZXRhaWxfcHJpY2UsXG4gICAgICAgICAgcmF0ZTogY2h1bmsucmF0ZSxcbiAgICAgICAgICBzdXBwbGllcjogY2h1bmsubWFrZXIsXG4gICAgICAgICAgYnJhbmQ6IGNodW5rLm1ha2VyLFxuICAgICAgICAgIHN0b2NrLFxuICAgICAgICAgIGRlbGl2ZXJ5LFxuICAgICAgICB9LFxuICAgICAgfTtcbiAgICAgIHJldHVybiBkb2M7XG4gICAgfTtcbiAgfVxufVxuIiwiaW1wb3J0IGZzIGZyb20gJ2ZzLWV4dHJhJztcbmltcG9ydCBpY29udiBmcm9tICdpY29udi1saXRlJztcbmltcG9ydCBjc3YgZnJvbSAnY3N2JztcbmltcG9ydCB7IFdyaXRhYmxlIH0gZnJvbSAnc3RyZWFtJztcbmltcG9ydCBNZXRhIGZyb20gJy4uL3NoYXJlZC9tZXRlb3JNb25nby9tZXRhJztcblxuZXhwb3J0IGNsYXNzIE1vbmdvIHtcbiAgLyoqXG4gICAqXG4gICAqXG4gICAqIEBzdGF0aWNcbiAgICogQHBhcmFtIHtTdHJpbmd9IGZpbGVcbiAgICogQHBhcmFtIHtpbXBvcnQoJ21vbmdvZGInKS5Db2xsZWN0aW9ufSBtY1xuICAgKiBAcmV0dXJuc1xuICAgKiBAbWVtYmVyb2YgTW9uZ29cbiAgICovXG4gIHN0YXRpYyBhc3luYyBpbXBvcnRDc3YoZmlsZSwgbWMpIHtcbiAgICBjb25zdCByZWFkID0gZnMuY3JlYXRlUmVhZFN0cmVhbShmaWxlKTtcbiAgICBjb25zdCB3cml0ZSA9IG5ldyBXcml0YWJsZSh7XG4gICAgICBvYmplY3RNb2RlOiB0cnVlLFxuICAgICAgYXN5bmMgd3JpdGUgKGNodW5rLCBlbmNvZGluZywgY2FsbGJhY2spIHtcbiAgICAgICAgLy8gdXNlIG1ldGEgZm9ybSBmb3IgZG9jdW1lbnRcbiAgICAgICAgY29uc3QgZG9jID0gTWV0YS53cmFwKGNodW5rKTtcblxuICAgICAgICAvLyBpbnNlcnQgdG8gbW9uZ28gY29sbGVjdGlvblxuICAgICAgICB0cnkge1xuICAgICAgICAgIGF3YWl0IG1jLmluc2VydChkb2MpO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBjYWxsYmFjayhlcnIpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gZG9uZSBjb3JyZWN0bHlcbiAgICAgICAgY2FsbGJhY2soKTtcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgcmVhZFxuICAgICAgICAucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1NKSVMnKSlcbiAgICAgICAgLnBpcGUoaWNvbnYuZW5jb2RlU3RyZWFtKCdVVEYtOCcpKVxuICAgICAgICAucGlwZShjc3YucGFyc2UoeyBjb2x1bW5zOiB0cnVlIH0pKVxuICAgICAgICAucGlwZSh3cml0ZSlcbiAgICAgICAgLm9uKCdmaW5pc2gnLCAoKSA9PiB7XG4gICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICB9KVxuICAgICAgICAub24oJ2Vycm9yJywgKGVycikgPT4ge1xuICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICB9KTtcbiAgICB9KTtcbiAgfVxufVxuIiwiaW1wb3J0IHsgUmVxdWVzdCB9IGZyb20gJy4uL2NvbGxlY3Rpb25zL3JlcXVlc3QnO1xuXG5leHBvcnQgY2xhc3MgUmVxdWVzdE1hbmFnZXIge1xuICBjb25zdHJ1Y3Rvcih0aXRsZSwgbWVzc2FnZSkge1xuICAgIHRoaXMuaWQgPSBSZXF1ZXN0Lmluc2VydChcbiAgICAgIHtcbiAgICAgICAgdGl0bGUsXG4gICAgICAgIG1lc3NhZ2UsXG4gICAgICAgIHN0YXJ0VGltZTogRGF0ZS5ub3coKSxcbiAgICAgICAgZW5kVGltZTogbnVsbCxcbiAgICAgIH0sXG4gICAgKTtcbiAgfVxuXG4gIGVuZChtZXNzYWdlKSB7XG4gICAgUmVxdWVzdC51cGRhdGUodGhpcy5pZCwge1xuICAgICAgJHNldDoge1xuICAgICAgICBtZXNzYWdlLFxuICAgICAgICBlbmRUaW1lOiBEYXRlLm5vdygpLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxufVxuIiwiaW1wb3J0IHsgSW1wb3J0SXJWQVJJQUJMRVMgfSBmcm9tICcuLi9jb2xsZWN0aW9ucy9pbXBvcnRJcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJy4uL2RhdGEvbW9uZ28nO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBJdGVtUm9ib3Qge1xuICBzdGF0aWMgYXN5bmMgaW1wb3J0QWxsKCkge1xuICAgIGF3YWl0IEl0ZW1Sb2JvdC5pbXBvcnRBbGxDc3YoKTtcbiAgfVxuXG4gIHN0YXRpYyBhc3luYyBpbXBvcnRBbGxDc3YoKSB7XG4gICAgY29uc3QgbWF4ID0gSW1wb3J0SXJWQVJJQUJMRVMuaXRlLmxlbmd0aDtcbiAgICBsZXQgY291bnQgPSAwO1xuXG4gICAgYXdhaXQgbmV3IFByb21pc2UoXG4gICAgICAocmVzb2x2ZSkgPT4ge1xuICAgICAgICBJbXBvcnRJclZBUklBQkxFUy5pdGUuZm9yRWFjaChcbiAgICAgICAgICBhc3luYyAoZSkgPT4ge1xuICAgICAgICAgICAgYXdhaXQgSXRlbVJvYm90LmltcG9ydENzdjJNb25nbyhcbiAgICAgICAgICAgICAgZS5tb25nb2NvbGwsXG4gICAgICAgICAgICAgIGAke0ltcG9ydElyVkFSSUFCTEVTLndvcmtkaXJ9LyR7ZS5jc3ZmaWxlfWAsXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgY291bnQgKz0gMTtcbiAgICAgICAgICAgIGlmIChjb3VudCA9PT0gbWF4KSB7XG4gICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICApO1xuICAgICAgfSxcbiAgICApO1xuICB9XG5cbiAgc3RhdGljIGFzeW5jIGltcG9ydENzdjJNb25nbyhtb25nb0NvbCwgY3N2RmlsZSkge1xuICAgIGF3YWl0IG1vbmdvQ29sLnJlbW92ZSgpO1xuICAgIGF3YWl0IE1vbmdvLmltcG9ydENzdihjc3ZGaWxlLCBtb25nb0NvbCk7XG4gIH1cbn1cbiIsImltcG9ydCAnLi92ZW5kZXIvaW1wb3J0JztcclxuIiwiaW1wb3J0IHsgQ29uZmlnIH0gZnJvbSAnLi4vaW1wb3J0cy9jb2xsZWN0aW9ucy9jb25maWcnO1xuXG5leHBvcnQgY2xhc3MgQ29uZmlnTWFuYWdlciB7XG4gIHN0YXRpYyBnZXQoKSB7XG4gICAgY29uc3QgY29uZmlnID0gQ29uZmlnLmZpbmRPbmUoKTtcbiAgICByZXR1cm4gY29uZmlnO1xuICB9XG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCBmcyBmcm9tICdmcy1leHRyYSc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgLyoqXG4gICAqXG4gICAqIEBwYXJhbSB7Kn0gZGlyXG4gICAqIEBwYXJhbSB7Kn0gZmlsZU5hbWVcbiAgICogQHBhcmFtIHtBcnJheUJ1ZmZlcn0gYmFzZTY0RGF0YVxuICAgKi9cbiAgYXN5bmMgJ2ZpbGUudXBsb2FkJyAoZGlyLCBmaWxlTmFtZSwgYmFzZTY0RGF0YSkge1xuICAgIGNvbnN0IGZ1bGxwYXRoID0gYCR7ZGlyfS8ke2ZpbGVOYW1lfWA7XG4gICAgYXdhaXQgZnMubWtkaXJzKGRpcik7XG5cbiAgICAvLyBjb252ZXJ0IGJhc2U2NCB0byBidWZmZXIuXG4gICAgY29uc3QgY2h1bmsgPSBCdWZmZXIuZnJvbShiYXNlNjREYXRhLCAnYmFzZTY0Jyk7XG5cbiAgICBjb25zdCByZXMgPSBhd2FpdCBmcy53cml0ZUZpbGUoZnVsbHBhdGgsIGNodW5rKTtcbiAgICByZXR1cm4gcmVzO1xuICB9LFxuXG4gIGFzeW5jICdmaWxlLnN0YXQnIChmaWxlTmFtZSkge1xuICAgIGxldCBzdGF0O1xuICAgIHRyeSB7XG4gICAgICBzdGF0ID0gYXdhaXQgZnMuc3RhdChmaWxlTmFtZSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihlKTtcbiAgICB9XG4gICAgcmV0dXJuIHN0YXQ7XG4gIH0sXG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IEl0ZW1Sb2JvdCBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbVJvYm90JztcbmltcG9ydCB7IEltcG9ydElySXRlbSwgSW1wb3J0SXJTZWxlY3Rpb24sIEltcG9ydElyVkFSSUFCTEVTIH0gZnJvbSAnLi4vaW1wb3J0cy9jb2xsZWN0aW9ucy9pbXBvcnRJcic7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgJ2ltcG9ydElyLmltcG9ydCcgKCkge1xuICAgIEl0ZW1Sb2JvdC5pbXBvcnRBbGwoKTtcblxuICAgIHJldHVybiB0cnVlO1xuICB9LFxuXG4gICdpbXBvcnRJci5zdGF0JyAoKSB7XG4gICAgY29uc3Qgc3RhdCA9IHt9O1xuXG4gICAgSW1wb3J0SXJWQVJJQUJMRVMuaXRlLmZvckVhY2goKGUpID0+IHtcbiAgICAgIGNvbnN0IG9iaiA9IHt9O1xuXG4gICAgICBvYmouY291bnQgPSBlLm1vbmdvQ29sbE1ldGVvci5maW5kKCkuY291bnQoKTtcblxuICAgICAgc3RhdFtlLnN5bWJvbF0gPSBvYmo7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gc3RhdDtcbiAgfSxcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nb09sZE5ld0l0ZW1zIH0gZnJvbSAnLi4vaW1wb3J0cy9jb252ZXJ0ZXIvbW9uZ29PbGROZXdJdGVtcyc7XG5pbXBvcnQgeyBDb25maWdNYW5hZ2VyIH0gZnJvbSAnLi9jb25maWcnO1xuaW1wb3J0IHsgUmVxdWVzdE1hbmFnZXIgfSBmcm9tICcuLi9pbXBvcnRzL3JlcXVldC9yZXF1ZXN0JztcbmltcG9ydCB7IE1vbmdvT2xkTmV3RXhoaWIgfSBmcm9tICcuLi9pbXBvcnRzL2NvbnZlcnRlci9tb25nb09sZE5ld0V4aGliJztcblxuY2xhc3MgSW5zdGFuY2Uge1xuICBzdGF0aWMgZ2V0KCkge1xuICAgIGNvbnN0IGluc3RhbmNlID0ge307XG5cbiAgICBjb25zdCBjb25maWcgPSBDb25maWdNYW5hZ2VyLmdldCgpO1xuICAgIGluc3RhbmNlLmNvbmZpZyA9IGNvbmZpZztcblxuICAgIGNvbnN0IG1vbmdvdU5ldyA9IGBtb25nb2RiOi8vJHtjb25maWcubW9uZ29JdGVtcy5ob3N0fToke2NvbmZpZy5tb25nb0l0ZW1zLnBvcnR9LyR7Y29uZmlnLm1vbmdvSXRlbXMuZGJ9YDtcbiAgICBjb25zdCBtb25nb3VPbGQgPSBgbW9uZ29kYjovLyR7Y29uZmlnLmxlZ2FjeS5tb25nb0l0ZW1zLmhvc3R9OiR7Y29uZmlnLmxlZ2FjeS5tb25nb0l0ZW1zLnBvcnR9LyR7Y29uZmlnLmxlZ2FjeS5tb25nb0l0ZW1zLmRifWA7XG5cbiAgICBpbnN0YW5jZS5tb25nb09sZE5ld0l0ZW1zID0gbmV3IE1vbmdvT2xkTmV3SXRlbXMobW9uZ291T2xkLCAncHJvZHVjdHMnLCBtb25nb3VOZXcsICdpdGVtcycpO1xuICAgIGluc3RhbmNlLm1vbmdvT2xkTmV3RXhoaWIgPSBuZXcgTW9uZ29PbGROZXdFeGhpYihtb25nb3VPbGQsICdpdGVtcycsIG1vbmdvdU5ldywgJ2V4aGliJyk7XG5cbiAgICByZXR1cm4gaW5zdGFuY2U7XG4gIH1cbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICBhc3luYyAnbWlncmF0aW9uLm1vbmdvT2xkTmV3Lml0ZW1zLmNvdW50JyAoKSB7XG4gICAgY29uc3QgaW5zdGFuY2UgPSBJbnN0YW5jZS5nZXQoKTtcbiAgICBjb25zdCBudW1iZXIgPSBhd2FpdCBpbnN0YW5jZS5tb25nb09sZE5ld0l0ZW1zLmNvdW50SW1wb3J0Q2FuZGlkYXRlKCk7XG4gICAgcmV0dXJuIG51bWJlcjtcbiAgfSxcblxuICAnbWlncmF0aW9uLm1vbmdvT2xkTmV3Lml0ZW1zJyAoKSB7XG4gICAgY29uc3QgaW5zdGFuY2UgPSBJbnN0YW5jZS5nZXQoKTtcbiAgICBjb25zdCBybSA9IG5ldyBSZXF1ZXN0TWFuYWdlcign5ZWG5ZOB5oOF5aCx44KSIG1vbmdvIOaXp+OBi+OCieaWsOODh+ODvOOCv+ODmeODvOOCueOBuCcsICfplovlp4vjgZfjgb7jgZfjgZ/jgIInKTtcblxuICAgIE1ldGVvci5kZWZlcihhc3luYygpID0+IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGluc3RhbmNlLm1vbmdvT2xkTmV3SXRlbXMubWlncmF0ZSgpO1xuICAgICAgcm0uZW5kKGAke3Jlc33ku7bjga7jg4fjg7zjgr/jgpLnp7vooYzjgZfjgb7jgZfjgZ/jgIJgKTtcbiAgICB9KTtcblxuICAgIHJldHVybiAnbW9uZ28g5pen44GL44KJ5paw44OH44O844K/44OZ44O844K544G444Gu5ZWG5ZOB5oOF5aCx56e76KGM44KS6ZaL5aeL44GX44G+44GX44Gf44CCJztcbiAgfSxcblxuICBhc3luYyAnbWlncmF0aW9uLm1vbmdvT2xkTmV3LmV4aGliLmNvdW50JyAoKSB7XG4gICAgY29uc3QgaW5zdGFuY2UgPSBJbnN0YW5jZS5nZXQoKTtcbiAgICBjb25zdCBudW1iZXIgPSBhd2FpdCBpbnN0YW5jZS5tb25nb09sZE5ld0V4aGliLmNvdW50SW1wb3J0Q2FuZGlkYXRlKCk7XG4gICAgcmV0dXJuIG51bWJlcjtcbiAgfSxcblxuICAnbWlncmF0aW9uLm1vbmdvT2xkTmV3LmV4aGliJyAoKSB7XG4gICAgY29uc3QgaW5zdGFuY2UgPSBJbnN0YW5jZS5nZXQoKTtcbiAgICBjb25zdCBybSA9IG5ldyBSZXF1ZXN0TWFuYWdlcign5Ye65ZOB5oOF5aCx44KSIG1vbmdvIOaXp+OBi+OCieaWsOODh+ODvOOCv+ODmeODvOOCueOBuCcsICfplovlp4vjgZfjgb7jgZfjgZ/jgIInKTtcblxuICAgIE1ldGVvci5kZWZlcihhc3luYygpID0+IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGluc3RhbmNlLm1vbmdvT2xkTmV3RXhoaWIubWlncmF0ZSgpO1xuICAgICAgcm0uZW5kKGAke3Jlc33ku7bjga7jg4fjg7zjgr/jgpLnp7vooYzjgZfjgb7jgZfjgZ/jgIJgKTtcbiAgICB9KTtcblxuICAgIHJldHVybiAnbW9uZ28g5pen44GL44KJ5paw44OH44O844K/44OZ44O844K544G444Gu5Ye65ZOB5oOF5aCx56e76KGM44KS6ZaL5aeL44GX44G+44GX44Gf44CCJztcbiAgfSxcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nb0NsaWVudCB9IGZyb20gJ21vbmdvZGInO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gIGFzeW5jICdtb25nby5jb25uZWN0LnRlc3QnIChtb25nb0Nvbm5lY3REb2MpIHtcbiAgICBsZXQgZGJjbGllbnQ7XG5cbiAgICB0cnkge1xuICAgICAgZGJjbGllbnQgPSBhd2FpdCBNb25nb0NsaWVudC5jb25uZWN0KFxuICAgICAgICBgbW9uZ29kYjovLyR7bW9uZ29Db25uZWN0RG9jLmhvc3R9OiR7bW9uZ29Db25uZWN0RG9jLnBvcnR9YCxcbiAgICAgICAgeyB1c2VOZXdVcmxQYXJzZXI6IHRydWUgfSxcbiAgICAgICk7XG5cbiAgICAgIGNvbnN0IGRiID0gZGJjbGllbnQuZGIobW9uZ29Db25uZWN0RG9jLmRiKTtcblxuICAgICAgY29uc3QgZGJpbmZvID0gYXdhaXQgZGIubGlzdENvbGxlY3Rpb25zKCkudG9BcnJheSgpO1xuXG4gICAgICByZXR1cm4gZGJpbmZvO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGlmIChlLm5hbWUpIHtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihlLm5hbWUsIGUubWVzc2FnZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBlO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBpZiAoZGJjbGllbnQpIGRiY2xpZW50LmNsb3NlKCk7XG4gICAgfVxuICB9LFxufSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCBteXNxbCBmcm9tICdteXNxbCc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgJ215c3FsLmNvbm5lY3QudGVzdCcgKG15c3FsY3JlZCkge1xuICAgIGNvbnN0IGNvbiA9IG15c3FsLmNyZWF0ZUNvbm5lY3Rpb24obXlzcWxjcmVkKTtcblxuICAgIE1ldGVvci53cmFwQXN5bmMoKG1jYikgPT4ge1xuICAgICAgY29uLmNvbm5lY3QoKGVycikgPT4ge1xuICAgICAgICBtY2IoZXJyKTtcbiAgICAgIH0pO1xuICAgIH0pKCk7XG5cbiAgICBjb25zdCByZXMgPSBNZXRlb3Iud3JhcEFzeW5jKChtY2IpID0+IHtcbiAgICAgIGNvbi5xdWVyeShgc2VsZWN0ICogZnJvbSBpbmZvcm1hdGlvbl9zY2hlbWEuU0NIRU1BVEEgd2hlcmUgU0NIRU1BX05BTUU9XCIke215c3FsY3JlZC5kYXRhYmFzZX1cImAsIChlcnIsIHJlc3VsdHMpID0+IHtcbiAgICAgICAgbWNiKGVyciwgcmVzdWx0cyk7XG4gICAgICB9KTtcbiAgICB9KSgpO1xuXG4gICAgY29uLmVuZCgpO1xuXG4gICAgY29uc3QgcmVzU3RyaW5nID0gSlNPTi5zdHJpbmdpZnkocmVzKTtcbiAgICBpZiAocmVzU3RyaW5nID09PSAnW10nKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCfjg4fjg7zjgr/jg5njg7zjgrnjgYzmjIflrprjgZXjgozjgabjgYTjgb7jgZvjgpPjgIInKTtcbiAgICB9XG5cbiAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkocmVzKTtcbiAgfSxcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBSZXF1ZXN0TWFuYWdlciB9IGZyb20gJy4uL2ltcG9ydHMvcmVxdWV0L3JlcXVlc3QnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICdyZXF1ZXN0LnRlc3QnICgpIHtcbiAgICBjb25zdCBybSA9IG5ldyBSZXF1ZXN0TWFuYWdlcignUmVxdWVzdCDjg4bjgrnjg4gnLCAn6ZaL5aeL44GX44G+44GX44GfJyk7XG5cbiAgICBNZXRlb3Iuc2V0VGltZW91dChcbiAgICAgICgpID0+IHtcbiAgICAgICAgcm0uZW5kKCfntYLkuobjgZfjgb7jgZfjgZ8nKTtcbiAgICAgIH0sIDEwMDAwLFxuICAgICk7XG5cbiAgICByZXR1cm4gJ1JlcXVlc3Qg44OG44K544OIIDEw56eS5b6M44Gr57WC5LqG44GX44G+44GZ44CCJztcbiAgfSxcbn0pO1xuIiwiaW1wb3J0IHsgQ29uZmlnIH0gZnJvbSAnLi4vaW1wb3J0cy9jb2xsZWN0aW9ucy9jb25maWcnO1xuaW1wb3J0IHsgSXRlbXMgfSBmcm9tICcuLi9pbXBvcnRzL2NvbGxlY3Rpb25zL2l0ZW1zJztcbmltcG9ydCAnLi4vaW1wb3J0cy9jb2xsZWN0aW9ucy9pbXBvcnRJcic7XG5cbmltcG9ydCAnLi4vaW1wb3J0cy9pbXBvcnQnO1xuXG4vLyBpbXBvcnQgeyBTdGF0c0NsaWVudCB9IGZyb20gJy4uL2ltcG9ydHMvY29sbGVjdGlvbnMvc3RhdHMnO1xuXG4vLyAvLyBjb25maWcgY2hlY2tcbi8vIGNvbnN0IENPTkZJR19GSUxFX05BTUUgPSAnYWRtaW4vY29uZmlnLmpzb24nO1xuLy8gbGV0IGNvbmZpZztcblxuLy8gdHJ5IHtcbi8vICAgY29uZmlnID0gQXNzZXRzLmdldFRleHQoQ09ORklHX0ZJTEVfTkFNRSk7XG4vLyAgIFN0YXRzQ2xpZW50LnVwZGF0ZSgnY29uZmlnLmZpbGVFeGlzdGFuY2UnLCAn5q2j5bi4Jyk7XG5cbi8vICAgY29uZmlnID0gSlNPTi5zdHJpbmdpZnkoY29uZmlnKTtcbi8vIH0gY2F0Y2ggKGVycikge1xuLy8gICBTdGF0c0NsaWVudC51cGRhdGUoJ2NvbmZpZy5maWxlRXhpc3RhbmNlJywgZXJyLnRvU3RyaW5nKCksIHRydWUpO1xuLy8gfVxuXG5cbi8vIGNvbmZpZyA9IGltcG9ydChDT05GSUdfRklMRV9OQU1FKTtcbi8vIFN0YXQudXBkYXRlKCdjb25maWcuZmlsZScsICfmraPluLgnKTtcblxuLy8gY2xhc3MgTG9hZENvbmZpZyB7XG4vLyAgIGNvbnN0cnVjdG9yKCkge1xuLy8gICAgIHRoaXMubG9nID0gW107XG4vLyAgIH1cblxuLy8gICBydW4oKSB7XG4vLyAgICAgdHJ5IHtcbi8vICAgICAgIGZzLmV4aXN0cyhDT05GSUdfRklMRV9OQU1FLCB0aGlzLm9uTG9vayk7XG4vLyAgICAgfSBjYXRjaCAoZXJyKSB7XG4vLyAgICAgICB0aGlzLmxvZy5wdXNoKGVycik7XG4vLyAgICAgfVxuXG4vLyAgICAgcmV0dXJuIHRoaXMubG9nO1xuLy8gICB9XG5cbi8vICAgb25Mb29rKGV4aXN0cykge1xuLy8gICAgIGlmICghZXhpc3RzKSB7XG4vLyAgICAgICBmcy5ta2RpcihDT05GSUdfRklMRV9OQU1FLCB0aGlzLm9uTWFrZSk7XG4vLyAgICAgfVxuXG4vLyAgICAgdGhpcy5vblJlYWR5KCk7XG4vLyAgIH1cblxuLy8gICBvbk1ha2UoZXJyKSB7XG4vLyAgICAgaWYgKGVycikge1xuLy8gICAgICAgdGhyb3cgZXJyO1xuLy8gICAgIH0gZWxzZSB7XG4vLyAgICAgICB0aGlzLm9uUmVhZHkoKTtcbi8vICAgICB9XG4vLyAgIH1cblxuLy8gICBvblJlYWR5KCkge1xuLy8gICAgIHRoaXMuZXhhbShpbXBvcnQoQ09ORklHX0ZJTEVfTkFNRSkpO1xuLy8gICB9XG5cbi8vICAgZXhhbShjb25maWcpIHtcbi8vICAgICBjb25zb2xlLmxvZyhjb25maWcpO1xuLy8gICB9XG4vLyB9XG5cbi8vIGNvbnN0IGxvYWRDb25maWcgPSBuZXcgTG9hZENvbmZpZygpO1xuLy8gbG9hZENvbmZpZy5ydW4oKTtcbiJdfQ==
