var require = meteorInstall({"collections":{"config.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// collections/config.js                                             //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.export({
  Config: () => Config
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
const Config = new Mongo.Collection('config', {
  idGeneration: 'MONGO'
});

if (Meteor.isServer) {
  if (!Config.findOne()) {
    Config.insert({});
  }

  Meteor.publish('config', () => Config.find({}, {
    limit: 1
  }));
}

Meteor.methods({
  'config.update'(doc) {
    Config.update({}, doc);
  }

});
///////////////////////////////////////////////////////////////////////

}},"server":{"mongo.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/mongo.js                                                   //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let mongodb;
module.link("mongodb", {
  default(v) {
    mongodb = v;
  }

}, 1);
Meteor.methods({
  'mongo.connect.test'(mongoConnectDoc) {
    return Promise.asyncApply(() => {
      let dbclient = null;

      try {
        dbclient = Promise.await(mongodb.MongoClient.connect(`mongodb://${mongoConnectDoc.host}:${mongoConnectDoc.port}`, {
          useNewUrlParser: true
        }));
      } catch (err) {
        return false;
      }

      console.log('db connection success');
      dbclient.close();
      return true;
    });
  }

});
///////////////////////////////////////////////////////////////////////

},"main.js":function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
///////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/collections/config.js");
require("/server/mongo.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvY29uZmlnLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbW9uZ28uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiQ29uZmlnIiwiTWV0ZW9yIiwibGluayIsInYiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJpZEdlbmVyYXRpb24iLCJpc1NlcnZlciIsImZpbmRPbmUiLCJpbnNlcnQiLCJwdWJsaXNoIiwiZmluZCIsImxpbWl0IiwibWV0aG9kcyIsImRvYyIsInVwZGF0ZSIsIm1vbmdvZGIiLCJkZWZhdWx0IiwibW9uZ29Db25uZWN0RG9jIiwiZGJjbGllbnQiLCJNb25nb0NsaWVudCIsImNvbm5lY3QiLCJob3N0IiwicG9ydCIsInVzZU5ld1VybFBhcnNlciIsImVyciIsImNvbnNvbGUiLCJsb2ciLCJjbG9zZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQUEsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0MsUUFBTSxFQUFDLE1BQUlBO0FBQVosQ0FBZDtBQUFtQyxJQUFJQyxNQUFKO0FBQVdILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVU4sTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFHdEcsTUFBTUgsTUFBTSxHQUFHLElBQUlJLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixRQUFyQixFQUErQjtBQUFFQyxjQUFZLEVBQUU7QUFBaEIsQ0FBL0IsQ0FBZjs7QUFFUCxJQUFJTCxNQUFNLENBQUNNLFFBQVgsRUFBcUI7QUFDbkIsTUFBSSxDQUFDUCxNQUFNLENBQUNRLE9BQVAsRUFBTCxFQUF1QjtBQUNyQlIsVUFBTSxDQUFDUyxNQUFQLENBQWMsRUFBZDtBQUNEOztBQUNEUixRQUFNLENBQUNTLE9BQVAsQ0FBZSxRQUFmLEVBQXlCLE1BQU1WLE1BQU0sQ0FBQ1csSUFBUCxDQUFZLEVBQVosRUFBZ0I7QUFBRUMsU0FBSyxFQUFFO0FBQVQsR0FBaEIsQ0FBL0I7QUFDRDs7QUFFRFgsTUFBTSxDQUFDWSxPQUFQLENBQWU7QUFDYixrQkFBaUJDLEdBQWpCLEVBQXNCO0FBQ3BCZCxVQUFNLENBQUNlLE1BQVAsQ0FBYyxFQUFkLEVBQWtCRCxHQUFsQjtBQUNEOztBQUhZLENBQWYsRTs7Ozs7Ozs7Ozs7QUNaQSxJQUFJYixNQUFKO0FBQVdILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlhLE9BQUo7QUFBWWxCLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFNBQVosRUFBc0I7QUFBQ2UsU0FBTyxDQUFDZCxDQUFELEVBQUc7QUFBQ2EsV0FBTyxHQUFDYixDQUFSO0FBQVU7O0FBQXRCLENBQXRCLEVBQThDLENBQTlDO0FBRzVFRixNQUFNLENBQUNZLE9BQVAsQ0FBZTtBQUNQLHNCQUFOLENBQTRCSyxlQUE1QjtBQUFBLG9DQUE2QztBQUMzQyxVQUFJQyxRQUFRLEdBQUcsSUFBZjs7QUFFQSxVQUFJO0FBQ0ZBLGdCQUFRLGlCQUFTSCxPQUFPLENBQUNJLFdBQVIsQ0FBb0JDLE9BQXBCLENBQ2QsYUFBWUgsZUFBZSxDQUFDSSxJQUFLLElBQUdKLGVBQWUsQ0FBQ0ssSUFBSyxFQUQzQyxFQUVmO0FBQUVDLHlCQUFlLEVBQUU7QUFBbkIsU0FGZSxDQUFULENBQVI7QUFJRCxPQUxELENBS0UsT0FBT0MsR0FBUCxFQUFZO0FBQ1osZUFBTyxLQUFQO0FBQ0Q7O0FBRURDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHVCQUFaO0FBQ0FSLGNBQVEsQ0FBQ1MsS0FBVDtBQUVBLGFBQU8sSUFBUDtBQUNELEtBaEJEO0FBQUE7O0FBRGEsQ0FBZixFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IENvbmZpZyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjb25maWcnLCB7IGlkR2VuZXJhdGlvbjogJ01PTkdPJyB9KTtcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICBpZiAoIUNvbmZpZy5maW5kT25lKCkpIHtcbiAgICBDb25maWcuaW5zZXJ0KHt9KTtcbiAgfVxuICBNZXRlb3IucHVibGlzaCgnY29uZmlnJywgKCkgPT4gQ29uZmlnLmZpbmQoe30sIHsgbGltaXQ6IDEgfSkpO1xufVxuXG5NZXRlb3IubWV0aG9kcyh7XG4gICdjb25maWcudXBkYXRlJyAoZG9jKSB7XG4gICAgQ29uZmlnLnVwZGF0ZSh7fSwgZG9jKTtcbiAgfSxcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgbW9uZ29kYiBmcm9tICdtb25nb2RiJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICBhc3luYyAnbW9uZ28uY29ubmVjdC50ZXN0JyAobW9uZ29Db25uZWN0RG9jKSB7XG4gICAgbGV0IGRiY2xpZW50ID0gbnVsbDtcblxuICAgIHRyeSB7XG4gICAgICBkYmNsaWVudCA9IGF3YWl0IG1vbmdvZGIuTW9uZ29DbGllbnQuY29ubmVjdChcbiAgICAgICAgYG1vbmdvZGI6Ly8ke21vbmdvQ29ubmVjdERvYy5ob3N0fToke21vbmdvQ29ubmVjdERvYy5wb3J0fWAsXG4gICAgICAgIHsgdXNlTmV3VXJsUGFyc2VyOiB0cnVlIH0sXG4gICAgICApO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKCdkYiBjb25uZWN0aW9uIHN1Y2Nlc3MnKTtcbiAgICBkYmNsaWVudC5jbG9zZSgpO1xuXG4gICAgcmV0dXJuIHRydWU7XG4gIH0sXG59KTtcbiJdfQ==
